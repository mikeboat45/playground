// ============================================================
// hooks/index.ts — Custom React hooks for TaskFlow
// ============================================================

'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { useStore } from '@/lib/store';
import type { Theme } from '@/types';

// ─── useTheme ────────────────────────────────────────────────

/**
 * Manages the application theme, respecting system preferences.
 * Applies the 'dark' class to <html> for Tailwind dark mode.
 */
export function useTheme() {
  const { theme, setTheme } = useStore();
  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    function applyTheme() {
      const isDark =
        theme === 'dark' || (theme === 'system' && mediaQuery.matches);
      document.documentElement.classList.toggle('dark', isDark);
      setResolvedTheme(isDark ? 'dark' : 'light');
    }

    applyTheme();
    mediaQuery.addEventListener('change', applyTheme);
    return () => mediaQuery.removeEventListener('change', applyTheme);
  }, [theme]);

  return { theme, resolvedTheme, setTheme };
}

// ─── useDebounce ─────────────────────────────────────────────

/**
 * Debounces a value — useful for search inputs to avoid too-frequent store updates.
 */
export function useDebounce<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);

  return debounced;
}

// ─── useLocalSearch ──────────────────────────────────────────

/**
 * Local search state that debounces updates to the global store filter.
 */
export function useLocalSearch() {
  const { filters, setFilters } = useStore();
  const [localSearch, setLocalSearch] = useState(filters.search);
  const debouncedSearch = useDebounce(localSearch, 250);

  useEffect(() => {
    setFilters({ search: debouncedSearch });
  }, [debouncedSearch, setFilters]);

  // Reset local state when filters are externally reset
  useEffect(() => {
    if (filters.search === '' && localSearch !== '') {
      setLocalSearch('');
    }
  }, [filters.search]);

  return { localSearch, setLocalSearch };
}

// ─── useModal ────────────────────────────────────────────────

/**
 * Simple boolean toggle hook for modals/drawers/popovers.
 */
export function useModal(initial = false) {
  const [isOpen, setIsOpen] = useState(initial);
  const open = useCallback(() => setIsOpen(true), []);
  const close = useCallback(() => setIsOpen(false), []);
  const toggle = useCallback(() => setIsOpen((v) => !v), []);
  return { isOpen, open, close, toggle };
}

// ─── useClickOutside ─────────────────────────────────────────

/**
 * Fires a callback when a click occurs outside the referenced element.
 */
export function useClickOutside<T extends HTMLElement>(
  handler: () => void,
): React.RefObject<T> {
  const ref = useRef<T>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        handler();
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [handler]);

  return ref;
}

// ─── useKeyboard ─────────────────────────────────────────────

/**
 * Registers keyboard shortcuts. Returns a cleanup function.
 * @example useKeyboard({ 'Escape': onClose, 'n': openNewTask });
 */
export function useKeyboard(
  shortcuts: Record<string, (e: KeyboardEvent) => void>,
  options?: { preventDefault?: boolean; ignoreInputs?: boolean },
) {
  const { preventDefault = false, ignoreInputs = true } = options ?? {};

  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (ignoreInputs) {
        const tag = (e.target as HTMLElement).tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      }

      const handler = shortcuts[e.key] ?? shortcuts[e.code];
      if (handler) {
        if (preventDefault) e.preventDefault();
        handler(e);
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [shortcuts, preventDefault, ignoreInputs]);
}

// ─── useMediaQuery ───────────────────────────────────────────

export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia(query);
    setMatches(mq.matches);
    const handler = (e: MediaQueryListEvent) => setMatches(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, [query]);

  return matches;
}

// ─── useIsMobile ─────────────────────────────────────────────

export function useIsMobile(): boolean {
  return useMediaQuery('(max-width: 768px)');
}

// ─── useAnimatedCounter ──────────────────────────────────────

/**
 * Smoothly animates a number from 0 to its target value.
 */
export function useAnimatedCounter(target: number, duration = 800): number {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    let startTime: number | null = null;
    const start = current;

    function step(timestamp: number) {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      // Ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setCurrent(Math.round(start + (target - start) * eased));
      if (progress < 1) requestAnimationFrame(step);
    }

    requestAnimationFrame(step);
  }, [target, duration]);

  return current;
}
