// ============================================================
// app/page.tsx — Main app page
// ============================================================

'use client';

import React, { useState, useCallback } from 'react';
import { useStore } from '@/lib/store';
import { useTheme, useKeyboard } from '@/hooks';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Toaster } from '@/components/layout/Toaster';
import { KanbanBoard } from '@/components/tasks/KanbanBoard';
import { TaskList } from '@/components/tasks/TaskList';
import { TaskModal } from '@/components/tasks/TaskModal';
import { FilterPanel } from '@/components/tasks/FilterPanel';
import { StatsBar } from '@/components/dashboard/StatsBar';
import type { Task, TaskStatus } from '@/types';

export default function Home() {
  // Initialise theme on mount
  useTheme();

  const { viewMode, filters, activeProjectId, projects } = useStore();

  // ── Modal / panel state ──────────────────────────────────────
  const [taskModalState, setTaskModalState] = useState<{
    open: boolean;
    task: Task | null;
    initialStatus?: TaskStatus;
  }>({ open: false, task: null });

  const [filterPanelOpen, setFilterPanelOpen] = useState(false);

  // ── Handlers ─────────────────────────────────────────────────

  const openNewTask = useCallback((status?: TaskStatus) => {
    setTaskModalState({ open: true, task: null, initialStatus: status });
  }, []);

  const openEditTask = useCallback((task: Task) => {
    setTaskModalState({ open: true, task, initialStatus: undefined });
  }, []);

  const closeTaskModal = useCallback(() => {
    setTaskModalState((prev) => ({ ...prev, open: false }));
  }, []);

  // Keyboard shortcuts
  useKeyboard({
    'n': () => openNewTask(),
    'f': () => setFilterPanelOpen((v) => !v),
    'Escape': () => {
      setFilterPanelOpen(false);
    },
  });

  // Count active (non-default) filters
  const activeFilterCount =
    filters.statuses.length +
    filters.priorities.length +
    filters.projectIds.length +
    filters.assigneeIds.length +
    (filters.search ? 1 : 0) +
    (!filters.showCompleted ? 1 : 0);

  // Active project for display
  const activeProject = activeProjectId
    ? projects.find((p) => p.id === activeProjectId)
    : null;

  return (
    <div className="flex h-screen overflow-hidden bg-surface-0">

      {/* ── Sidebar ───────────────────────────────────────────── */}
      <Sidebar
        onNewProject={() => {/* TODO: project modal */}}
        onNewTask={() => openNewTask()}
      />

      {/* ── Main area ─────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">

        {/* Top header */}
        <Header
          onFilterClick={() => setFilterPanelOpen((v) => !v)}
          activeFilterCount={activeFilterCount}
        />

        {/* Page title bar */}
        <div className="shrink-0 px-4 py-2.5 flex items-center gap-2 border-b border-border">
          {activeProject ? (
            <>
              <span className="text-lg leading-none">{activeProject.emoji}</span>
              <h1 className="text-sm font-semibold text-text-primary font-display">{activeProject.name}</h1>
              <span className="text-xs text-text-muted">{activeProject.description}</span>
            </>
          ) : (
            <h1 className="text-sm font-semibold text-text-primary font-display">All Tasks</h1>
          )}
          <div className="ml-auto flex items-center gap-2">
            <span className="text-[11px] text-text-muted hidden sm:block">
              Press <kbd className="px-1 py-0.5 text-[10px] rounded border border-border bg-surface-2 font-mono">N</kbd> for new task ·{' '}
              <kbd className="px-1 py-0.5 text-[10px] rounded border border-border bg-surface-2 font-mono">F</kbd> to filter
            </span>
          </div>
        </div>

        {/* Stats bar */}
        <StatsBar />

        {/* Content area — board or list view */}
        <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 overflow-hidden">
            {viewMode === 'board' ? (
              <KanbanBoard onOpenTask={openEditTask} onNewTask={openNewTask} />
            ) : (
              <TaskList onOpenTask={openEditTask} onNewTask={() => openNewTask()} />
            )}
          </div>

          {/* Filter panel — slides in from right */}
          {filterPanelOpen && (
            <FilterPanel onClose={() => setFilterPanelOpen(false)} />
          )}
        </div>
      </div>

      {/* ── Task Modal ─────────────────────────────────────────── */}
      {taskModalState.open && (
        <TaskModal
          task={taskModalState.task}
          initialStatus={taskModalState.initialStatus}
          onClose={closeTaskModal}
        />
      )}

      {/* ── Toast Notifications ───────────────────────────────── */}
      <Toaster />
    </div>
  );
}
