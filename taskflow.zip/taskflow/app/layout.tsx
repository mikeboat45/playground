// ============================================================
// app/layout.tsx — Root layout
// ============================================================

import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'TaskFlow — Advanced Project Management',
  description: 'A powerful task management dashboard built with Next.js 14, TypeScript, and Tailwind CSS.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Prevent FOUC for dark mode — runs before React hydrates */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                const stored = JSON.parse(localStorage.getItem('taskflow-storage') || '{}');
                const theme = stored?.state?.theme ?? 'system';
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                if (theme === 'dark' || (theme === 'system' && prefersDark)) {
                  document.documentElement.classList.add('dark');
                }
              } catch {}
            `,
          }}
        />
      </head>
      <body className="h-screen overflow-hidden bg-surface-0 text-text-primary font-sans">
        {children}
      </body>
    </html>
  );
}
