# TaskFlow — Advanced Next.js Task Management Dashboard

A production-grade task management app built with **Next.js 14 App Router**, **TypeScript**, **Tailwind CSS**, **Zustand**, and **@dnd-kit**.

---

## ✨ Features

- **Kanban Board** — Drag-and-drop cards across columns (To Do / In Progress / Blocked / Done)
- **List View** — Sortable table with inline actions
- **Advanced Filters** — Filter by status, priority, project, assignee, and more
- **Task Modal** — Create and edit tasks with subtasks, tags, due dates, priority, and estimated hours
- **Statistics Bar** — Live KPI cards with animated counters + Recharts bar & pie charts
- **Dark / Light Mode** — Persisted to `localStorage`, respects system preference, no FOUC
- **Keyboard Shortcuts** — `N` new task, `F` toggle filters, `Escape` to close
- **Toast Notifications** — Auto-dismissing success / error / info / warning toasts
- **Zustand Store** — Typed global state with `persist` middleware for UI preferences
- **Seed Data** — 15 realistic tasks across 4 projects and 4 team members pre-loaded

---

## 🗂 Project Structure

```
taskflow/
├── app/
│   ├── globals.css          # Design tokens (CSS vars), Tailwind, Google Fonts
│   ├── layout.tsx           # Root layout + FOUC-prevention script
│   └── page.tsx             # Main app shell
├── components/
│   ├── ui/                  # Design system primitives (Button, Badge, Avatar, Input…)
│   ├── layout/              # Sidebar, Header, Toaster
│   ├── tasks/               # KanbanBoard, TaskCard, TaskList, TaskModal, FilterPanel
│   └── dashboard/           # StatsBar with Recharts
├── hooks/
│   └── index.ts             # useTheme, useDebounce, useKeyboard, useModal…
├── lib/
│   ├── data.ts              # Seed data (tasks, projects, users)
│   ├── store.ts             # Zustand store + selectors
│   └── utils.ts             # cn(), filter/sort engine, date helpers
└── types/
    └── index.ts             # All TypeScript interfaces and types
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn or pnpm

### Install & Run

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev

# 3. Open in browser
open http://localhost:3000
```

### Build for Production

```bash
npm run build
npm start
```

### Type Check

```bash
npm run type-check
```

---

## 🎨 Design System

The app uses a **warm off-white / deep charcoal** palette with an **amber accent**, plus:

- **Display font**: [Syne](https://fonts.google.com/specimen/Syne) — bold, editorial
- **Body font**: [DM Sans](https://fonts.google.com/specimen/DM+Sans) — clean, versatile
- **Mono font**: [JetBrains Mono](https://fonts.google.com/specimen/JetBrains+Mono) — for code/kbd

All colors are CSS custom properties under `--surface-*`, `--text-*`, `--accent*`, `--border*` toggled by the `.dark` class on `<html>`.

---

## 🧩 Architecture Decisions

| Concern | Choice | Why |
|---|---|---|
| State management | Zustand | Minimal boilerplate, great TypeScript support, easy devtools |
| Drag and drop | @dnd-kit | Accessible, composable, no jQuery dependency |
| Charts | Recharts | Declarative React API, responsive containers |
| Styling | Tailwind CSS | Utility-first, design token integration, purge by default |
| Persistence | Zustand persist | Only persists UI prefs (theme, sort, view mode), not data |
| Date handling | date-fns | Tree-shakeable, no moment.js weight |

---

## ⌨️ Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `N` | New task |
| `F` | Toggle filter panel |
| `Escape` | Close modal / filter panel |

---

## 📦 Key Dependencies

```json
{
  "next": "14.x",
  "react": "18.x",
  "zustand": "^4.5",
  "framer-motion": "^11",
  "@dnd-kit/core": "^6",
  "@dnd-kit/sortable": "^8",
  "recharts": "^2.12",
  "date-fns": "^3",
  "lucide-react": "^0.383",
  "clsx": "^2",
  "tailwind-merge": "^2",
  "nanoid": "^5"
}
```
