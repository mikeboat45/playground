/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Enable experimental features for advanced patterns
  experimental: {
    typedRoutes: true,
  },
};

module.exports = nextConfig;
