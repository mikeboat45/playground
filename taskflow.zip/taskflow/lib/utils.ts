// ============================================================
// lib/utils.ts — Shared utility functions
// ============================================================

import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { formatDistanceToNow, format, isPast, isToday, isTomorrow } from 'date-fns';
import type { Priority, TaskStatus, Task, TaskFilters, SortConfig } from '@/types';

/** Merge Tailwind classes safely */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ─── Priority helpers ────────────────────────────────────────

export const PRIORITY_ORDER: Record<Priority, number> = {
  low: 1,
  medium: 2,
  high: 3,
  critical: 4,
};

export const PRIORITY_LABELS: Record<Priority, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

export const PRIORITY_COLORS: Record<Priority, string> = {
  low: 'text-blue-500',
  medium: 'text-yellow-500',
  high: 'text-orange-500',
  critical: 'text-red-500',
};

export const PRIORITY_BG: Record<Priority, string> = {
  low: 'bg-blue-500/10 text-blue-600 dark:text-blue-400',
  medium: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400',
  high: 'bg-orange-500/10 text-orange-600 dark:text-orange-400',
  critical: 'bg-red-500/10 text-red-600 dark:text-red-400',
};

// ─── Status helpers ──────────────────────────────────────────

export const STATUS_LABELS: Record<TaskStatus, string> = {
  'todo': 'To Do',
  'in-progress': 'In Progress',
  'done': 'Done',
  'blocked': 'Blocked',
};

export const STATUS_COLORS: Record<TaskStatus, string> = {
  'todo': 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300',
  'in-progress': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
  'done': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300',
  'blocked': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',
};

export const STATUS_DOT: Record<TaskStatus, string> = {
  'todo': 'bg-slate-400',
  'in-progress': 'bg-blue-500',
  'done': 'bg-green-500',
  'blocked': 'bg-red-500',
};

// ─── Date helpers ────────────────────────────────────────────

export function formatDate(dateStr: string | null): string {
  if (!dateStr) return '—';
  const date = new Date(dateStr);
  if (isToday(date)) return 'Today';
  if (isTomorrow(date)) return 'Tomorrow';
  return format(date, 'MMM d, yyyy');
}

export function formatDateShort(dateStr: string | null): string {
  if (!dateStr) return '—';
  return format(new Date(dateStr), 'MMM d');
}

export function formatRelative(dateStr: string): string {
  return formatDistanceToNow(new Date(dateStr), { addSuffix: true });
}

export function isOverdue(task: Task): boolean {
  if (!task.dueDate || task.status === 'done') return false;
  return isPast(new Date(task.dueDate)) && !isToday(new Date(task.dueDate));
}

export function isDueToday(task: Task): boolean {
  if (!task.dueDate || task.status === 'done') return false;
  return isToday(new Date(task.dueDate));
}

// ─── Filter & Sort engine ────────────────────────────────────

export function filterTasks(tasks: Task[], filters: TaskFilters): Task[] {
  return tasks.filter((task) => {
    // Search
    if (filters.search) {
      const q = filters.search.toLowerCase();
      const match =
        task.title.toLowerCase().includes(q) ||
        task.description.toLowerCase().includes(q) ||
        task.tags.some((t) => t.toLowerCase().includes(q));
      if (!match) return false;
    }

    // Status
    if (filters.statuses.length > 0 && !filters.statuses.includes(task.status)) return false;

    // Priority
    if (filters.priorities.length > 0 && !filters.priorities.includes(task.priority)) return false;

    // Project
    if (filters.projectIds.length > 0 && !filters.projectIds.includes(task.projectId)) return false;

    // Assignee
    if (filters.assigneeIds.length > 0) {
      if (!task.assigneeId || !filters.assigneeIds.includes(task.assigneeId)) return false;
    }

    // Tags
    if (filters.tags.length > 0 && !filters.tags.some((t) => task.tags.includes(t))) return false;

    // Due date range
    if (filters.dueDateRange.from && task.dueDate) {
      if (new Date(task.dueDate) < new Date(filters.dueDateRange.from)) return false;
    }
    if (filters.dueDateRange.to && task.dueDate) {
      if (new Date(task.dueDate) > new Date(filters.dueDateRange.to)) return false;
    }

    // Hide completed
    if (!filters.showCompleted && task.status === 'done') return false;

    return true;
  });
}

export function sortTasks(tasks: Task[], sort: SortConfig): Task[] {
  return [...tasks].sort((a, b) => {
    let comparison = 0;

    switch (sort.field) {
      case 'title':
        comparison = a.title.localeCompare(b.title);
        break;
      case 'priority':
        comparison = PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority];
        break;
      case 'dueDate':
        if (!a.dueDate && !b.dueDate) comparison = 0;
        else if (!a.dueDate) comparison = 1;
        else if (!b.dueDate) comparison = -1;
        else comparison = new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        break;
      case 'createdAt':
        comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        break;
      case 'status': {
        const statusOrder: Record<TaskStatus, number> = { todo: 1, 'in-progress': 2, blocked: 3, done: 4 };
        comparison = statusOrder[a.status] - statusOrder[b.status];
        break;
      }
    }

    return sort.direction === 'asc' ? comparison : -comparison;
  });
}

// ─── Misc ────────────────────────────────────────────────────

/** Get initials from a name */
export function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

/** Generate a random pastel color from a string (deterministic) */
export function stringToColor(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const colors = [
    '#f97316', '#f59e0b', '#10b981', '#3b82f6',
    '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16',
  ];
  return colors[Math.abs(hash) % colors.length];
}

/** Calculate task completion percentage */
export function getCompletionPercent(tasks: Task[]): number {
  if (tasks.length === 0) return 0;
  const done = tasks.filter((t) => t.status === 'done').length;
  return Math.round((done / tasks.length) * 100);
}

/** Truncate a string to a max length */
export function truncate(str: string, max: number): string {
  return str.length > max ? str.slice(0, max) + '…' : str;
}

/** Debounce a function */
export function debounce<T extends (...args: unknown[]) => unknown>(fn: T, delay: number): T {
  let timer: ReturnType<typeof setTimeout>;
  return ((...args: unknown[]) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  }) as T;
}
