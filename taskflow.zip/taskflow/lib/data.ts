// ============================================================
// lib/data.ts — Seed data for TaskFlow demo
// ============================================================

import type { Task, Project, User, ActivityEntry } from '@/types';

export const SEED_USERS: User[] = [
  { id: 'u1', name: 'Alex Rivera', email: 'alex@taskflow.io', avatar: 'AR', role: 'owner', color: '#f97316' },
  { id: 'u2', name: 'Jordan Kim', email: 'jordan@taskflow.io', avatar: 'JK', role: 'admin', color: '#3b82f6' },
  { id: 'u3', name: 'Sam Chen', email: 'sam@taskflow.io', avatar: 'SC', role: 'member', color: '#10b981' },
  { id: 'u4', name: 'Taylor West', email: 'taylor@taskflow.io', avatar: 'TW', role: 'member', color: '#8b5cf6' },
];

export const SEED_PROJECTS: Project[] = [
  {
    id: 'p1', name: 'Product Redesign', description: 'Full redesign of the core product UI/UX',
    color: '#f97316', emoji: '🎨', ownerId: 'u1', memberIds: ['u1', 'u2', 'u3'],
    createdAt: '2024-10-01T00:00:00Z', archivedAt: null,
  },
  {
    id: 'p2', name: 'API v3 Migration', description: 'Migrate all endpoints to the new v3 REST API spec',
    color: '#3b82f6', emoji: '⚡', ownerId: 'u2', memberIds: ['u1', 'u2', 'u4'],
    createdAt: '2024-11-15T00:00:00Z', archivedAt: null,
  },
  {
    id: 'p3', name: 'Mobile App', description: 'iOS and Android companion app',
    color: '#10b981', emoji: '📱', ownerId: 'u1', memberIds: ['u1', 'u3', 'u4'],
    createdAt: '2025-01-10T00:00:00Z', archivedAt: null,
  },
  {
    id: 'p4', name: 'Analytics Dashboard', description: 'Real-time analytics for enterprise customers',
    color: '#8b5cf6', emoji: '📊', ownerId: 'u3', memberIds: ['u1', 'u2', 'u3', 'u4'],
    createdAt: '2025-02-20T00:00:00Z', archivedAt: null,
  },
];

const now = new Date();
const d = (daysOffset: number) => new Date(now.getTime() + daysOffset * 86400000).toISOString().split('T')[0];

export const SEED_TASKS: Task[] = [
  // Product Redesign
  {
    id: 't1', title: 'Audit current component library', description: 'Document all existing components, identify inconsistencies and deprecated patterns.',
    status: 'done', priority: 'high', projectId: 'p1', assigneeId: 'u3',
    tags: ['design-system', 'audit'], dueDate: d(-5), createdAt: d(-20) + 'T10:00:00Z', updatedAt: d(-5) + 'T10:00:00Z',
    completedAt: d(-5) + 'T14:30:00Z', estimatedHours: 8, loggedHours: 7.5,
    subtasks: [
      { id: 'st1', title: 'List all Button variants', completed: true },
      { id: 'st2', title: 'List all Form components', completed: true },
      { id: 'st3', title: 'Document color usage', completed: true },
    ],
    attachments: [], comments: [], order: 0,
  },
  {
    id: 't2', title: 'Design new token system', description: 'Create a scalable design token system for colors, spacing, typography, and elevation.',
    status: 'done', priority: 'critical', projectId: 'p1', assigneeId: 'u2',
    tags: ['design-system', 'tokens'], dueDate: d(-2), createdAt: d(-18) + 'T10:00:00Z', updatedAt: d(-2) + 'T10:00:00Z',
    completedAt: d(-2) + 'T16:00:00Z', estimatedHours: 12, loggedHours: 14,
    subtasks: [
      { id: 'st4', title: 'Color tokens', completed: true },
      { id: 'st5', title: 'Spacing scale', completed: true },
    ],
    attachments: [], comments: [], order: 1,
  },
  {
    id: 't3', title: 'Rebuild navigation component', description: 'New responsive navigation with keyboard accessibility, mobile drawer, and breadcrumb support.',
    status: 'in-progress', priority: 'high', projectId: 'p1', assigneeId: 'u1',
    tags: ['components', 'accessibility'], dueDate: d(3), createdAt: d(-10) + 'T10:00:00Z', updatedAt: d(-1) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 16, loggedHours: 9,
    subtasks: [
      { id: 'st6', title: 'Desktop layout', completed: true },
      { id: 'st7', title: 'Mobile drawer', completed: false },
      { id: 'st8', title: 'Keyboard navigation', completed: false },
    ],
    attachments: [], comments: [], order: 0,
  },
  {
    id: 't4', title: 'Create design documentation site', description: 'Storybook-style documentation with live examples for all design system components.',
    status: 'in-progress', priority: 'medium', projectId: 'p1', assigneeId: 'u4',
    tags: ['docs', 'storybook'], dueDate: d(7), createdAt: d(-8) + 'T10:00:00Z', updatedAt: d(-2) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 20, loggedHours: 8,
    subtasks: [], attachments: [], comments: [], order: 1,
  },
  {
    id: 't5', title: 'Migrate Button component', description: 'Replace old Button with new design system version across all 47 usages in the codebase.',
    status: 'todo', priority: 'high', projectId: 'p1', assigneeId: 'u3',
    tags: ['components', 'migration'], dueDate: d(10), createdAt: d(-5) + 'T10:00:00Z', updatedAt: d(-5) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 8, loggedHours: 0,
    subtasks: [], attachments: [], comments: [], order: 0,
  },
  {
    id: 't6', title: 'Accessibility audit', description: 'WCAG 2.1 AA compliance audit for all redesigned components.',
    status: 'todo', priority: 'critical', projectId: 'p1', assigneeId: null,
    tags: ['accessibility', 'audit'], dueDate: d(14), createdAt: d(-3) + 'T10:00:00Z', updatedAt: d(-3) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 12, loggedHours: 0,
    subtasks: [], attachments: [], comments: [], order: 1,
  },
  // API v3 Migration
  {
    id: 't7', title: 'Write OpenAPI spec v3', description: 'Document all endpoints with request/response schemas in OpenAPI 3.1 format.',
    status: 'done', priority: 'critical', projectId: 'p2', assigneeId: 'u2',
    tags: ['api', 'docs'], dueDate: d(-7), createdAt: d(-25) + 'T10:00:00Z', updatedAt: d(-7) + 'T10:00:00Z',
    completedAt: d(-7) + 'T11:00:00Z', estimatedHours: 16, loggedHours: 18,
    subtasks: [], attachments: [], comments: [], order: 0,
  },
  {
    id: 't8', title: 'Implement rate limiting', description: 'Token bucket algorithm for per-user and per-IP rate limiting on all API routes.',
    status: 'in-progress', priority: 'high', projectId: 'p2', assigneeId: 'u4',
    tags: ['api', 'security'], dueDate: d(2), createdAt: d(-12) + 'T10:00:00Z', updatedAt: d(0) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 10, loggedHours: 6,
    subtasks: [
      { id: 'st9', title: 'Redis integration', completed: true },
      { id: 'st10', title: 'Per-route config', completed: false },
    ],
    attachments: [], comments: [], order: 0,
  },
  {
    id: 't9', title: 'Database schema migration', description: 'Run and validate Prisma migrations for new v3 schema. Requires zero-downtime strategy.',
    status: 'blocked', priority: 'critical', projectId: 'p2', assigneeId: 'u1',
    tags: ['database', 'migration'], dueDate: d(1), createdAt: d(-9) + 'T10:00:00Z', updatedAt: d(-1) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 6, loggedHours: 2,
    subtasks: [], attachments: [], comments: [], order: 0,
  },
  {
    id: 't10', title: 'Update SDK clients', description: 'Regenerate TypeScript and Python SDK clients from new OpenAPI spec.',
    status: 'todo', priority: 'medium', projectId: 'p2', assigneeId: 'u2',
    tags: ['sdk'], dueDate: d(12), createdAt: d(-4) + 'T10:00:00Z', updatedAt: d(-4) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 6, loggedHours: 0,
    subtasks: [], attachments: [], comments: [], order: 0,
  },
  // Mobile App
  {
    id: 't11', title: 'Setup React Native project', description: 'Initialize RN project with navigation, state management, and CI/CD pipeline.',
    status: 'done', priority: 'high', projectId: 'p3', assigneeId: 'u3',
    tags: ['setup', 'react-native'], dueDate: d(-10), createdAt: d(-30) + 'T10:00:00Z', updatedAt: d(-10) + 'T10:00:00Z',
    completedAt: d(-10) + 'T12:00:00Z', estimatedHours: 12, loggedHours: 10,
    subtasks: [], attachments: [], comments: [], order: 0,
  },
  {
    id: 't12', title: 'Implement offline sync', description: 'SQLite local database with conflict resolution for offline-first task management.',
    status: 'in-progress', priority: 'critical', projectId: 'p3', assigneeId: 'u4',
    tags: ['offline', 'sync'], dueDate: d(6), createdAt: d(-14) + 'T10:00:00Z', updatedAt: d(-1) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 24, loggedHours: 14,
    subtasks: [
      { id: 'st11', title: 'SQLite schema', completed: true },
      { id: 'st12', title: 'Sync engine', completed: true },
      { id: 'st13', title: 'Conflict resolution', completed: false },
      { id: 'st14', title: 'Background sync', completed: false },
    ],
    attachments: [], comments: [], order: 0,
  },
  {
    id: 't13', title: 'Push notification service', description: 'Firebase Cloud Messaging integration for task reminders and assignment alerts.',
    status: 'todo', priority: 'medium', projectId: 'p3', assigneeId: null,
    tags: ['notifications', 'firebase'], dueDate: d(18), createdAt: d(-6) + 'T10:00:00Z', updatedAt: d(-6) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 10, loggedHours: 0,
    subtasks: [], attachments: [], comments: [], order: 0,
  },
  // Analytics Dashboard
  {
    id: 't14', title: 'Design chart component library', description: 'Reusable Recharts wrappers with consistent theming for bar, line, pie, and sparkline charts.',
    status: 'in-progress', priority: 'high', projectId: 'p4', assigneeId: 'u1',
    tags: ['charts', 'components'], dueDate: d(5), createdAt: d(-11) + 'T10:00:00Z', updatedAt: d(-1) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 14, loggedHours: 8,
    subtasks: [], attachments: [], comments: [], order: 0,
  },
  {
    id: 't15', title: 'Real-time WebSocket updates', description: 'Live dashboard updates via WebSocket. Metrics should update within 5 seconds of an event.',
    status: 'todo', priority: 'high', projectId: 'p4', assigneeId: 'u2',
    tags: ['websocket', 'real-time'], dueDate: d(9), createdAt: d(-5) + 'T10:00:00Z', updatedAt: d(-5) + 'T10:00:00Z',
    completedAt: null, estimatedHours: 16, loggedHours: 0,
    subtasks: [], attachments: [], comments: [], order: 0,
  },
];

export const SEED_ACTIVITY: ActivityEntry[] = [
  {
    id: 'a1', type: 'completed', taskId: 't2', taskTitle: 'Design new token system',
    userId: 'u2', metadata: {}, timestamp: new Date(now.getTime() - 2 * 3600000).toISOString(),
  },
  {
    id: 'a2', type: 'status_changed', taskId: 't8', taskTitle: 'Implement rate limiting',
    userId: 'u4', metadata: { from: 'todo', to: 'in-progress' }, timestamp: new Date(now.getTime() - 5 * 3600000).toISOString(),
  },
  {
    id: 'a3', type: 'created', taskId: 't15', taskTitle: 'Real-time WebSocket updates',
    userId: 'u1', metadata: {}, timestamp: new Date(now.getTime() - 8 * 3600000).toISOString(),
  },
  {
    id: 'a4', type: 'assigned', taskId: 't12', taskTitle: 'Implement offline sync',
    userId: 'u1', metadata: { assigneeId: 'u4' }, timestamp: new Date(now.getTime() - 24 * 3600000).toISOString(),
  },
  {
    id: 'a5', type: 'status_changed', taskId: 't9', taskTitle: 'Database schema migration',
    userId: 'u1', metadata: { from: 'in-progress', to: 'blocked' }, timestamp: new Date(now.getTime() - 26 * 3600000).toISOString(),
  },
];
