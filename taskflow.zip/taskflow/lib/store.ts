// ============================================================
// lib/store.ts — Zustand global state management
// ============================================================

import { create } from 'zustand';
import { persist, devtools } from 'zustand/middleware';
import { nanoid } from 'nanoid';
import type { AppState, Task, TaskStatus, TaskFilters, SortConfig, ViewMode, Theme, Notification, Project } from '@/types';
import { SEED_TASKS, SEED_PROJECTS, SEED_USERS, SEED_ACTIVITY } from './data';

const DEFAULT_FILTERS: TaskFilters = {
  search: '',
  statuses: [],
  priorities: [],
  projectIds: [],
  assigneeIds: [],
  tags: [],
  dueDateRange: { from: null, to: null },
  showCompleted: true,
};

const DEFAULT_SORT: SortConfig = {
  field: 'createdAt',
  direction: 'desc',
};

export const useStore = create<AppState>()(
  devtools(
    persist(
      (set, get) => ({
        // ── Initial State ────────────────────────────────────
        tasks: SEED_TASKS,
        projects: SEED_PROJECTS,
        users: SEED_USERS,
        currentUserId: 'u1',
        filters: DEFAULT_FILTERS,
        sort: DEFAULT_SORT,
        viewMode: 'board',
        theme: 'system',
        activeProjectId: null,
        notifications: [],
        activityLog: SEED_ACTIVITY,
        isLoading: false,

        // ── Task Actions ─────────────────────────────────────

        addTask: (taskData) => {
          const now = new Date().toISOString();
          // Calculate order: place at end of its status column
          const { tasks } = get();
          const columnTasks = tasks.filter((t) => t.status === taskData.status);
          const maxOrder = columnTasks.reduce((max, t) => Math.max(max, t.order), -1);

          const newTask: Task = {
            ...taskData,
            id: nanoid(10),
            createdAt: now,
            updatedAt: now,
            completedAt: null,
            loggedHours: 0,
            order: maxOrder + 1,
          };

          set((state) => ({
            tasks: [...state.tasks, newTask],
            activityLog: [
              {
                id: nanoid(),
                type: 'created',
                taskId: newTask.id,
                taskTitle: newTask.title,
                userId: state.currentUserId,
                metadata: {},
                timestamp: now,
              },
              ...state.activityLog,
            ],
          }));

          get().addNotification({
            type: 'success',
            title: 'Task created',
            message: `"${newTask.title}" added successfully.`,
          });
        },

        updateTask: (id, updates) => {
          const now = new Date().toISOString();
          set((state) => ({
            tasks: state.tasks.map((t) =>
              t.id === id
                ? {
                    ...t,
                    ...updates,
                    updatedAt: now,
                    // Automatically set completedAt when marking as done
                    completedAt: updates.status === 'done' ? now : updates.status ? null : t.completedAt,
                  }
                : t,
            ),
          }));
        },

        deleteTask: (id) => {
          const task = get().tasks.find((t) => t.id === id);
          set((state) => ({
            tasks: state.tasks.filter((t) => t.id !== id),
          }));
          if (task) {
            get().addNotification({ type: 'info', title: 'Task deleted', message: `"${task.title}" was removed.` });
          }
        },

        moveTask: (taskId, newStatus, newOrder) => {
          const now = new Date().toISOString();
          const oldTask = get().tasks.find((t) => t.id === taskId);

          set((state) => ({
            tasks: state.tasks.map((t) =>
              t.id === taskId
                ? {
                    ...t,
                    status: newStatus,
                    order: newOrder,
                    updatedAt: now,
                    completedAt: newStatus === 'done' ? now : newStatus !== t.status ? null : t.completedAt,
                  }
                : t,
            ),
          }));

          // Log status change activity
          if (oldTask && oldTask.status !== newStatus) {
            set((state) => ({
              activityLog: [
                {
                  id: nanoid(),
                  type: 'status_changed',
                  taskId,
                  taskTitle: oldTask.title,
                  userId: state.currentUserId,
                  metadata: { from: oldTask.status, to: newStatus },
                  timestamp: now,
                },
                ...state.activityLog.slice(0, 49), // Keep last 50 entries
              ],
            }));
          }
        },

        reorderTasks: (status, orderedIds) => {
          set((state) => ({
            tasks: state.tasks.map((t) => {
              if (t.status !== status) return t;
              const newOrder = orderedIds.indexOf(t.id);
              return newOrder === -1 ? t : { ...t, order: newOrder };
            }),
          }));
        },

        // ── Project Actions ──────────────────────────────────

        addProject: (projectData) => {
          const newProject: Project = {
            ...projectData,
            id: nanoid(10),
            createdAt: new Date().toISOString(),
          };
          set((state) => ({ projects: [...state.projects, newProject] }));
          get().addNotification({ type: 'success', title: 'Project created', message: `"${newProject.name}" is ready.` });
        },

        updateProject: (id, updates) => {
          set((state) => ({
            projects: state.projects.map((p) => (p.id === id ? { ...p, ...updates } : p)),
          }));
        },

        // ── UI Actions ───────────────────────────────────────

        setFilters: (partial) => {
          set((state) => ({ filters: { ...state.filters, ...partial } }));
        },

        resetFilters: () => {
          set({ filters: DEFAULT_FILTERS });
        },

        setSort: (sort: SortConfig) => {
          set({ sort });
        },

        setViewMode: (mode: ViewMode) => {
          set({ viewMode: mode });
        },

        setTheme: (theme: Theme) => {
          set({ theme });
        },

        setActiveProject: (id) => {
          set({ activeProjectId: id });
          // Reset project filter to match sidebar selection
          set((state) => ({
            filters: {
              ...state.filters,
              projectIds: id ? [id] : [],
            },
          }));
        },

        // ── Notifications ────────────────────────────────────

        addNotification: (n) => {
          const notification = { ...n, id: nanoid() };
          set((state) => ({
            notifications: [...state.notifications, notification],
          }));
          // Auto-dismiss after duration (default 4s)
          setTimeout(() => {
            get().removeNotification(notification.id);
          }, n.duration ?? 4000);
        },

        removeNotification: (id) => {
          set((state) => ({
            notifications: state.notifications.filter((n) => n.id !== id),
          }));
        },
      }),
      {
        name: 'taskflow-storage',
        // Only persist UI preferences, not data (data would come from API in production)
        partialize: (state) => ({
          viewMode: state.viewMode,
          theme: state.theme,
          sort: state.sort,
          currentUserId: state.currentUserId,
        }),
      },
    ),
    { name: 'TaskFlow Store' },
  ),
);

// ─── Derived selectors ────────────────────────────────────────
// These compute derived data without duplicating state.

export const useCurrentUser = () => {
  const { users, currentUserId } = useStore();
  return users.find((u) => u.id === currentUserId) ?? users[0];
};

export const useProject = (id: string | null) => {
  const { projects } = useStore();
  return id ? projects.find((p) => p.id === id) ?? null : null;
};

export const useFilteredTasks = () => {
  const { tasks, filters, sort, activeProjectId } = useStore();
  const { filterTasks, sortTasks } = require('./utils');

  // If activeProjectId is set, filter to that project
  const effectiveFilters = activeProjectId
    ? { ...filters, projectIds: filters.projectIds.length ? filters.projectIds : [activeProjectId] }
    : filters;

  return sortTasks(filterTasks(tasks, effectiveFilters), sort) as Task[];
};

export const useTasksByStatus = (status: TaskStatus) => {
  const tasks = useFilteredTasks();
  return tasks
    .filter((t) => t.status === status)
    .sort((a, b) => a.order - b.order);
};

export const useTaskStats = () => {
  const { tasks, activeProjectId } = useStore();
  const projectTasks = activeProjectId ? tasks.filter((t) => t.projectId === activeProjectId) : tasks;

  const byStatus = {
    todo: projectTasks.filter((t) => t.status === 'todo').length,
    'in-progress': projectTasks.filter((t) => t.status === 'in-progress').length,
    done: projectTasks.filter((t) => t.status === 'done').length,
    blocked: projectTasks.filter((t) => t.status === 'blocked').length,
  };

  const completionRate = projectTasks.length
    ? Math.round((byStatus.done / projectTasks.length) * 100)
    : 0;

  const now = new Date();
  const overdueCount = projectTasks.filter(
    (t) => t.dueDate && t.status !== 'done' && new Date(t.dueDate) < now,
  ).length;

  const byPriority = {
    low: projectTasks.filter((t) => t.priority === 'low').length,
    medium: projectTasks.filter((t) => t.priority === 'medium').length,
    high: projectTasks.filter((t) => t.priority === 'high').length,
    critical: projectTasks.filter((t) => t.priority === 'critical').length,
  };

  return {
    total: projectTasks.length,
    byStatus,
    byPriority,
    completionRate,
    overdueCount,
  };
};
