// ============================================================
// components/ui/index.tsx — Reusable design system primitives
// ============================================================

'use client';

import React, { forwardRef } from 'react';
import { cn } from '@/lib/utils';

// ─── Button ──────────────────────────────────────────────────

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline';
  size?: 'xs' | 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'secondary', size = 'md', loading, icon, iconRight, children, className, disabled, ...props }, ref) => {
    const base = 'inline-flex items-center justify-center gap-1.5 font-medium rounded-lg transition-all duration-150 select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 active:scale-[0.97] disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100';

    const variants = {
      primary: 'bg-accent text-white hover:bg-accent-hover shadow-sm',
      secondary: 'bg-surface-2 text-text-primary hover:bg-surface-3 border border-border',
      ghost: 'text-text-secondary hover:bg-surface-2 hover:text-text-primary',
      danger: 'bg-red-500 text-white hover:bg-red-600 shadow-sm',
      outline: 'border border-border text-text-primary hover:bg-surface-2',
    };

    const sizes = {
      xs: 'h-6 px-2 text-xs gap-1',
      sm: 'h-7 px-2.5 text-sm',
      md: 'h-8 px-3 text-sm',
      lg: 'h-10 px-4 text-base',
    };

    return (
      <button
        ref={ref}
        className={cn(base, variants[variant], sizes[size], className)}
        disabled={disabled || loading}
        {...props}
      >
        {loading ? <Spinner size={size === 'lg' ? 'md' : 'sm'} /> : icon}
        {children}
        {!loading && iconRight}
      </button>
    );
  },
);
Button.displayName = 'Button';

// ─── Spinner ─────────────────────────────────────────────────

export function Spinner({ size = 'md', className }: { size?: 'sm' | 'md' | 'lg'; className?: string }) {
  const sizes = { sm: 'w-3.5 h-3.5', md: 'w-4 h-4', lg: 'w-5 h-5' };
  return (
    <svg
      className={cn('animate-spin', sizes[size], className)}
      viewBox="0 0 24 24"
      fill="none"
    >
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeOpacity="0.25" />
      <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

// ─── Badge ───────────────────────────────────────────────────

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'neutral';
  size?: 'sm' | 'md';
  dot?: boolean;
  className?: string;
}

export function Badge({ children, variant = 'default', size = 'md', dot, className }: BadgeProps) {
  const variants = {
    default: 'bg-surface-2 text-text-secondary border border-border',
    success: 'bg-green-500/10 text-green-600 dark:text-green-400',
    warning: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400',
    danger: 'bg-red-500/10 text-red-600 dark:text-red-400',
    info: 'bg-blue-500/10 text-blue-600 dark:text-blue-400',
    neutral: 'bg-surface-2 text-text-muted',
  };
  const dotColors = {
    default: 'bg-text-muted', success: 'bg-green-500', warning: 'bg-yellow-500',
    danger: 'bg-red-500', info: 'bg-blue-500', neutral: 'bg-text-muted',
  };
  const sizes = { sm: 'h-5 px-1.5 text-xs', md: 'h-6 px-2 text-xs' };

  return (
    <span className={cn('inline-flex items-center gap-1 rounded-md font-medium', variants[variant], sizes[size], className)}>
      {dot && <span className={cn('w-1.5 h-1.5 rounded-full', dotColors[variant])} />}
      {children}
    </span>
  );
}

// ─── Avatar ──────────────────────────────────────────────────

interface AvatarProps {
  name: string;
  color?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  className?: string;
}

export function Avatar({ name, color = '#6b7280', size = 'md', className }: AvatarProps) {
  const initials = name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2);
  const sizes = { xs: 'w-5 h-5 text-[10px]', sm: 'w-6 h-6 text-xs', md: 'w-7 h-7 text-xs', lg: 'w-9 h-9 text-sm' };

  return (
    <span
      className={cn('inline-flex items-center justify-center rounded-full font-semibold text-white shrink-0 select-none', sizes[size], className)}
      style={{ backgroundColor: color }}
      title={name}
    >
      {initials}
    </span>
  );
}

// ─── Input ───────────────────────────────────────────────────

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ icon, iconRight, error, className, ...props }, ref) => (
    <div className="relative w-full">
      {icon && (
        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none">
          {icon}
        </span>
      )}
      <input
        ref={ref}
        className={cn(
          'w-full h-8 rounded-lg border bg-surface-1 px-3 text-sm text-text-primary placeholder:text-text-muted',
          'border-border focus:outline-none focus:ring-2 focus:ring-accent/50 focus:border-accent',
          'transition-colors duration-150',
          error && 'border-red-500 focus:ring-red-500/30',
          icon && 'pl-8',
          iconRight && 'pr-8',
          className,
        )}
        {...props}
      />
      {iconRight && (
        <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-text-muted">
          {iconRight}
        </span>
      )}
      {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
    </div>
  ),
);
Input.displayName = 'Input';

// ─── Textarea ────────────────────────────────────────────────

export const Textarea = forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => (
    <textarea
      ref={ref}
      className={cn(
        'w-full rounded-lg border bg-surface-1 px-3 py-2 text-sm text-text-primary placeholder:text-text-muted',
        'border-border focus:outline-none focus:ring-2 focus:ring-accent/50 focus:border-accent',
        'transition-colors duration-150 resize-none',
        className,
      )}
      {...props}
    />
  ),
);
Textarea.displayName = 'Textarea';

// ─── Select ──────────────────────────────────────────────────

export const Select = forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement>>(
  ({ className, children, ...props }, ref) => (
    <select
      ref={ref}
      className={cn(
        'w-full h-8 rounded-lg border bg-surface-1 px-2.5 text-sm text-text-primary',
        'border-border focus:outline-none focus:ring-2 focus:ring-accent/50',
        'transition-colors duration-150 cursor-pointer',
        className,
      )}
      {...props}
    >
      {children}
    </select>
  ),
);
Select.displayName = 'Select';

// ─── Card ────────────────────────────────────────────────────

export function Card({ children, className, onClick, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        'rounded-xl bg-surface-1 border border-border shadow-card',
        onClick && 'cursor-pointer hover:shadow-card-hover hover:border-border-strong transition-all duration-150',
        className,
      )}
      onClick={onClick}
      {...props}
    >
      {children}
    </div>
  );
}

// ─── Divider ─────────────────────────────────────────────────

export function Divider({ className }: { className?: string }) {
  return <hr className={cn('border-0 border-t border-border', className)} />;
}

// ─── Tooltip ─────────────────────────────────────────────────

export function Tooltip({ children, label, className }: { children: React.ReactNode; label: string; className?: string }) {
  return (
    <div className={cn('relative group inline-flex', className)}>
      {children}
      <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 px-2 py-1 text-xs text-white bg-gray-900 dark:bg-gray-700 rounded-md whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-150 z-50">
        {label}
      </span>
    </div>
  );
}

// ─── Empty State ─────────────────────────────────────────────

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      {icon && <div className="mb-3 text-text-muted opacity-50">{icon}</div>}
      <p className="text-sm font-medium text-text-secondary">{title}</p>
      {description && <p className="mt-1 text-xs text-text-muted max-w-xs">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

// ─── Progress Bar ────────────────────────────────────────────

export function ProgressBar({ value, max = 100, className, colorClass = 'bg-accent' }: {
  value: number; max?: number; className?: string; colorClass?: string;
}) {
  const pct = Math.min(Math.max((value / max) * 100, 0), 100);
  return (
    <div className={cn('h-1.5 rounded-full bg-surface-3 overflow-hidden', className)}>
      <div
        className={cn('h-full rounded-full transition-all duration-500', colorClass)}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

// ─── Kbd ─────────────────────────────────────────────────────

export function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono rounded border border-border bg-surface-2 text-text-muted">
      {children}
    </kbd>
  );
}
