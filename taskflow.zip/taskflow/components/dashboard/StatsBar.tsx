// ============================================================
// components/dashboard/StatsBar.tsx — KPI cards + activity
// ============================================================

'use client';

import React from 'react';
import {
  CheckCircle2, Clock, AlertTriangle, TrendingUp,
  Activity, BarChart3, Zap,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip,
  ResponsiveContainer, Cell, PieChart, Pie,
} from 'recharts';
import { useStore, useTaskStats } from '@/lib/store';
import { Card, Avatar, Badge, ProgressBar } from '@/components/ui';
import { cn, formatRelative, STATUS_LABELS } from '@/lib/utils';
import { useAnimatedCounter } from '@/hooks';
import type { ActivityEntry } from '@/types';

export function StatsBar() {
  const stats = useTaskStats();
  const { activityLog, users, tasks } = useStore();

  const barData = [
    { name: 'To Do', value: stats.byStatus['todo'], color: '#94a3b8' },
    { name: 'In Progress', value: stats.byStatus['in-progress'], color: '#3b82f6' },
    { name: 'Blocked', value: stats.byStatus['blocked'], color: '#ef4444' },
    { name: 'Done', value: stats.byStatus['done'], color: '#22c55e' },
  ];

  const priorityData = [
    { name: 'Low', value: stats.byPriority['low'], color: '#3b82f6' },
    { name: 'Med', value: stats.byPriority['medium'], color: '#f59e0b' },
    { name: 'High', value: stats.byPriority['high'], color: '#f97316' },
    { name: 'Crit', value: stats.byPriority['critical'], color: '#ef4444' },
  ].filter((d) => d.value > 0);

  return (
    <div className="shrink-0 border-b border-border bg-surface-0 px-4 py-3">
      <div className="flex items-start gap-3 overflow-x-auto pb-1">

        {/* KPI Cards */}
        <StatCard
          label="Total Tasks"
          value={stats.total}
          icon={<BarChart3 className="w-4 h-4" />}
          color="text-blue-500"
        />
        <StatCard
          label="Completion"
          value={stats.completionRate}
          suffix="%"
          icon={<CheckCircle2 className="w-4 h-4" />}
          color="text-green-500"
          subtext={`${stats.byStatus['done']} done`}
        />
        <StatCard
          label="In Progress"
          value={stats.byStatus['in-progress']}
          icon={<Clock className="w-4 h-4" />}
          color="text-blue-500"
        />
        <StatCard
          label="Overdue"
          value={stats.overdueCount}
          icon={<AlertTriangle className="w-4 h-4" />}
          color={stats.overdueCount > 0 ? 'text-red-500' : 'text-text-muted'}
          alert={stats.overdueCount > 0}
        />

        {/* Status bar chart */}
        <div className="shrink-0 w-44 h-[72px] bg-surface-1 rounded-xl border border-border px-3 py-2">
          <p className="text-[10px] font-semibold text-text-muted uppercase tracking-wider mb-1">By Status</p>
          <ResponsiveContainer width="100%" height={42}>
            <BarChart data={barData} barSize={10} barGap={2}>
              <XAxis dataKey="name" tick={{ fontSize: 8, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
              <RechartsTooltip
                cursor={{ fill: 'transparent' }}
                contentStyle={{ background: 'var(--surface-0)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 11 }}
              />
              <Bar dataKey="value" radius={[2, 2, 0, 0]}>
                {barData.map((d, i) => <Cell key={i} fill={d.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Priority pie */}
        {priorityData.length > 0 && (
          <div className="shrink-0 w-44 h-[72px] bg-surface-1 rounded-xl border border-border px-3 py-2 flex items-center gap-3">
            <div>
              <p className="text-[10px] font-semibold text-text-muted uppercase tracking-wider mb-1">Priority</p>
              <div className="space-y-0.5">
                {priorityData.map((d) => (
                  <div key={d.name} className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: d.color }} />
                    <span className="text-[10px] text-text-secondary">{d.name}</span>
                    <span className="text-[10px] text-text-muted ml-auto">{d.value}</span>
                  </div>
                ))}
              </div>
            </div>
            <ResponsiveContainer width={50} height={50}>
              <PieChart>
                <Pie data={priorityData} cx="50%" cy="50%" innerRadius={14} outerRadius={22} dataKey="value" strokeWidth={0}>
                  {priorityData.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Recent Activity */}
        <div className="shrink-0 w-64 h-[72px] bg-surface-1 rounded-xl border border-border px-3 py-2 overflow-hidden">
          <p className="text-[10px] font-semibold text-text-muted uppercase tracking-wider mb-1.5">Recent Activity</p>
          <div className="space-y-1">
            {activityLog.slice(0, 2).map((entry) => (
              <ActivityItem key={entry.id} entry={entry} users={users} />
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}

// ─── Stat Card ────────────────────────────────────────────────

function StatCard({
  label, value, suffix = '', icon, color, subtext, alert,
}: {
  label: string; value: number; suffix?: string;
  icon: React.ReactNode; color: string;
  subtext?: string; alert?: boolean;
}) {
  const animated = useAnimatedCounter(value, 600);

  return (
    <div className={cn(
      'shrink-0 h-[72px] w-32 rounded-xl bg-surface-1 border px-3 py-2 flex flex-col justify-between',
      alert && value > 0 ? 'border-red-300 dark:border-red-900 bg-red-50/50 dark:bg-red-900/10' : 'border-border',
    )}>
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-semibold text-text-muted uppercase tracking-wider">{label}</span>
        <span className={cn('opacity-70', color)}>{icon}</span>
      </div>
      <div>
        <span className={cn('text-2xl font-bold font-display leading-none', color)}>
          {animated}{suffix}
        </span>
        {subtext && <p className="text-[10px] text-text-muted mt-0.5">{subtext}</p>}
      </div>
    </div>
  );
}

// ─── Activity Item ────────────────────────────────────────────

function ActivityItem({
  entry,
  users,
}: {
  entry: ActivityEntry;
  users: ReturnType<typeof useStore>['users'];
}) {
  const user = users.find((u) => u.id === entry.userId);

  const actionText: Record<ActivityEntry['type'], string> = {
    created: 'created',
    status_changed: `moved to ${STATUS_LABELS[(entry.metadata as { to?: string }).to as keyof typeof STATUS_LABELS ?? 'todo']}`,
    assigned: 'assigned',
    commented: 'commented on',
    completed: 'completed',
  };

  return (
    <div className="flex items-center gap-1.5 min-w-0">
      {user && <Avatar name={user.name} color={user.color} size="xs" />}
      <p className="text-[10px] text-text-secondary truncate">
        <span className="font-medium">{user?.name.split(' ')[0]}</span>{' '}
        {actionText[entry.type]}{' '}
        <span className="text-text-muted">"{entry.taskTitle}"</span>
      </p>
    </div>
  );
}
