// ============================================================
// components/tasks/FilterPanel.tsx — Advanced filter sidebar
// ============================================================

'use client';

import React from 'react';
import { X, RotateCcw } from 'lucide-react';
import { useStore } from '@/lib/store';
import { Button, Avatar, Badge, Divider } from '@/components/ui';
import { cn, PRIORITY_LABELS, STATUS_LABELS, STATUS_DOT } from '@/lib/utils';
import type { TaskStatus, Priority } from '@/types';

interface FilterPanelProps {
  onClose: () => void;
}

export function FilterPanel({ onClose }: FilterPanelProps) {
  const { filters, setFilters, resetFilters, projects, users } = useStore();

  function toggleStatus(s: TaskStatus) {
    const next = filters.statuses.includes(s)
      ? filters.statuses.filter((x) => x !== s)
      : [...filters.statuses, s];
    setFilters({ statuses: next });
  }

  function togglePriority(p: Priority) {
    const next = filters.priorities.includes(p)
      ? filters.priorities.filter((x) => x !== p)
      : [...filters.priorities, p];
    setFilters({ priorities: next });
  }

  function toggleProject(id: string) {
    const next = filters.projectIds.includes(id)
      ? filters.projectIds.filter((x) => x !== id)
      : [...filters.projectIds, id];
    setFilters({ projectIds: next });
  }

  function toggleAssignee(id: string) {
    const next = filters.assigneeIds.includes(id)
      ? filters.assigneeIds.filter((x) => x !== id)
      : [...filters.assigneeIds, id];
    setFilters({ assigneeIds: next });
  }

  const statuses: TaskStatus[] = ['todo', 'in-progress', 'blocked', 'done'];
  const priorities: Priority[] = ['low', 'medium', 'high', 'critical'];

  const priorityColors: Record<Priority, string> = {
    low: 'bg-blue-500',
    medium: 'bg-yellow-500',
    high: 'bg-orange-500',
    critical: 'bg-red-500',
  };

  const activeCount =
    filters.statuses.length +
    filters.priorities.length +
    filters.projectIds.length +
    filters.assigneeIds.length;

  return (
    <div className="w-64 shrink-0 h-full flex flex-col bg-surface-0 border-l border-border overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-text-primary">Filters</span>
          {activeCount > 0 && (
            <span className="text-xs font-bold bg-accent text-white rounded-full w-4 h-4 flex items-center justify-center">
              {activeCount}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {activeCount > 0 && (
            <Button variant="ghost" size="xs" onClick={resetFilters} icon={<RotateCcw className="w-3 h-3" />}>
              Reset
            </Button>
          )}
          <Button variant="ghost" size="xs" className="w-6 h-6 p-0" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-5">

        {/* Show completed */}
        <label className="flex items-center justify-between cursor-pointer">
          <span className="text-sm text-text-secondary">Show completed</span>
          <button
            role="switch"
            aria-checked={filters.showCompleted}
            onClick={() => setFilters({ showCompleted: !filters.showCompleted })}
            className={cn(
              'relative w-8 h-4.5 rounded-full transition-colors duration-200',
              filters.showCompleted ? 'bg-accent' : 'bg-surface-3',
            )}
          >
            <span className={cn(
              'absolute top-0.5 w-3.5 h-3.5 rounded-full bg-white shadow transition-transform duration-200',
              filters.showCompleted ? 'translate-x-[18px]' : 'translate-x-0.5',
            )} />
          </button>
        </label>

        <Divider />

        {/* Status */}
        <div>
          <p className="text-xs font-semibold text-text-muted uppercase tracking-wider mb-2">Status</p>
          <div className="space-y-1">
            {statuses.map((s) => (
              <label key={s} className="flex items-center gap-2.5 cursor-pointer group">
                <div
                  onClick={() => toggleStatus(s)}
                  className={cn(
                    'w-4 h-4 rounded border-2 flex items-center justify-center transition-all duration-150 cursor-pointer shrink-0',
                    filters.statuses.includes(s)
                      ? 'bg-accent border-accent'
                      : 'border-border group-hover:border-accent/60',
                  )}
                >
                  {filters.statuses.includes(s) && (
                    <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 12 12">
                      <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <span className="flex items-center gap-1.5 text-sm text-text-secondary group-hover:text-text-primary transition-colors" onClick={() => toggleStatus(s)}>
                  <span className={cn('w-1.5 h-1.5 rounded-full', STATUS_DOT[s])} />
                  {STATUS_LABELS[s]}
                </span>
              </label>
            ))}
          </div>
        </div>

        <Divider />

        {/* Priority */}
        <div>
          <p className="text-xs font-semibold text-text-muted uppercase tracking-wider mb-2">Priority</p>
          <div className="space-y-1">
            {priorities.map((p) => (
              <label key={p} className="flex items-center gap-2.5 cursor-pointer group">
                <div
                  onClick={() => togglePriority(p)}
                  className={cn(
                    'w-4 h-4 rounded border-2 flex items-center justify-center transition-all duration-150 cursor-pointer shrink-0',
                    filters.priorities.includes(p)
                      ? 'bg-accent border-accent'
                      : 'border-border group-hover:border-accent/60',
                  )}
                >
                  {filters.priorities.includes(p) && (
                    <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 12 12">
                      <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <span className="flex items-center gap-1.5 text-sm text-text-secondary group-hover:text-text-primary transition-colors" onClick={() => togglePriority(p)}>
                  <span className={cn('w-1.5 h-1.5 rounded-full', priorityColors[p])} />
                  {PRIORITY_LABELS[p]}
                </span>
              </label>
            ))}
          </div>
        </div>

        <Divider />

        {/* Projects */}
        <div>
          <p className="text-xs font-semibold text-text-muted uppercase tracking-wider mb-2">Projects</p>
          <div className="space-y-1">
            {projects.map((project) => (
              <label key={project.id} className="flex items-center gap-2.5 cursor-pointer group" onClick={() => toggleProject(project.id)}>
                <div className={cn(
                  'w-4 h-4 rounded border-2 flex items-center justify-center transition-all duration-150 shrink-0',
                  filters.projectIds.includes(project.id)
                    ? 'bg-accent border-accent'
                    : 'border-border group-hover:border-accent/60',
                )}>
                  {filters.projectIds.includes(project.id) && (
                    <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 12 12">
                      <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <span className="flex items-center gap-1.5 text-sm text-text-secondary group-hover:text-text-primary transition-colors">
                  <span>{project.emoji}</span>
                  <span className="truncate">{project.name}</span>
                </span>
              </label>
            ))}
          </div>
        </div>

        <Divider />

        {/* Assignees */}
        <div>
          <p className="text-xs font-semibold text-text-muted uppercase tracking-wider mb-2">Assignee</p>
          <div className="space-y-1">
            {users.map((user) => (
              <label key={user.id} className="flex items-center gap-2.5 cursor-pointer group" onClick={() => toggleAssignee(user.id)}>
                <div className={cn(
                  'w-4 h-4 rounded border-2 flex items-center justify-center transition-all duration-150 shrink-0',
                  filters.assigneeIds.includes(user.id)
                    ? 'bg-accent border-accent'
                    : 'border-border group-hover:border-accent/60',
                )}>
                  {filters.assigneeIds.includes(user.id) && (
                    <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 12 12">
                      <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <span className="flex items-center gap-1.5 text-sm text-text-secondary group-hover:text-text-primary transition-colors">
                  <Avatar name={user.name} color={user.color} size="xs" />
                  <span className="truncate">{user.name}</span>
                </span>
              </label>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
