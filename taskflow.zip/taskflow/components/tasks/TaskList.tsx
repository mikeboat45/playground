// ============================================================
// components/tasks/TaskList.tsx — Table/list view of tasks
// ============================================================

'use client';

import React, { useState } from 'react';
import {
  ChevronUp, ChevronDown, Calendar, AlertCircle,
  CheckCircle2, Circle, Clock, ArrowUpDown, Trash2, Edit3,
} from 'lucide-react';
import { useStore, useFilteredTasks } from '@/lib/store';
import { Avatar, Badge, Button, EmptyState, ProgressBar } from '@/components/ui';
import {
  cn, formatDate, isOverdue, isDueToday,
  PRIORITY_BG, PRIORITY_LABELS, STATUS_LABELS, STATUS_COLORS, STATUS_DOT,
} from '@/lib/utils';
import type { Task, SortField, TaskStatus } from '@/types';

interface TaskListProps {
  onOpenTask: (task: Task) => void;
  onNewTask: () => void;
}

export function TaskList({ onOpenTask, onNewTask }: TaskListProps) {
  const { sort, setSort, deleteTask, updateTask, users } = useStore();
  const tasks = useFilteredTasks();

  function handleSort(field: SortField) {
    if (sort.field === field) {
      setSort({ field, direction: sort.direction === 'asc' ? 'desc' : 'asc' });
    } else {
      setSort({ field, direction: 'asc' });
    }
  }

  function SortIcon({ field }: { field: SortField }) {
    if (sort.field !== field) return <ArrowUpDown className="w-3 h-3 opacity-40" />;
    return sort.direction === 'asc'
      ? <ChevronUp className="w-3 h-3 text-accent" />
      : <ChevronDown className="w-3 h-3 text-accent" />;
  }

  const th = 'px-3 py-2 text-left text-xs font-semibold text-text-muted select-none';
  const sortable = 'cursor-pointer hover:text-text-primary transition-colors';

  return (
    <div className="flex-1 overflow-auto px-4 pt-3 pb-4">
      {tasks.length === 0 ? (
        <EmptyState
          title="No tasks match your filters"
          description="Try adjusting your search or filters to find what you're looking for."
          action={<Button variant="primary" size="sm" onClick={onNewTask}>Create a task</Button>}
        />
      ) : (
        <div className="rounded-xl border border-border overflow-hidden bg-surface-0 shadow-card">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-border bg-surface-1">
                <th className={cn(th, 'w-6 pl-3')}></th>
                <th className={cn(th, 'min-w-[200px]')}>
                  <button className={cn('flex items-center gap-1', sortable)} onClick={() => handleSort('title')}>
                    Title <SortIcon field="title" />
                  </button>
                </th>
                <th className={cn(th)}>
                  <button className={cn('flex items-center gap-1', sortable)} onClick={() => handleSort('status')}>
                    Status <SortIcon field="status" />
                  </button>
                </th>
                <th className={cn(th)}>
                  <button className={cn('flex items-center gap-1', sortable)} onClick={() => handleSort('priority')}>
                    Priority <SortIcon field="priority" />
                  </button>
                </th>
                <th className={cn(th, 'hidden md:table-cell')}>Assignee</th>
                <th className={cn(th, 'hidden lg:table-cell')}>
                  <button className={cn('flex items-center gap-1', sortable)} onClick={() => handleSort('dueDate')}>
                    Due Date <SortIcon field="dueDate" />
                  </button>
                </th>
                <th className={cn(th, 'hidden lg:table-cell')}>Progress</th>
                <th className={cn(th, 'w-16 text-right pr-3')}>Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {tasks.map((task) => (
                <TaskRow
                  key={task.id}
                  task={task}
                  onOpen={onOpenTask}
                  onDelete={deleteTask}
                  onToggleDone={(t) =>
                    updateTask(t.id, { status: t.status === 'done' ? 'todo' : 'done' })
                  }
                  users={users}
                />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── Task Row ─────────────────────────────────────────────────

function TaskRow({
  task,
  onOpen,
  onDelete,
  onToggleDone,
  users,
}: {
  task: Task;
  onOpen: (t: Task) => void;
  onDelete: (id: string) => void;
  onToggleDone: (t: Task) => void;
  users: ReturnType<typeof useStore>['users'];
}) {
  const assignee = task.assigneeId ? users.find((u) => u.id === task.assigneeId) : null;
  const overdue = isOverdue(task);
  const dueToday = isDueToday(task);
  const isDone = task.status === 'done';
  const subtasksDone = task.subtasks.filter((s) => s.completed).length;
  const [hovered, setHovered] = useState(false);

  return (
    <tr
      className={cn(
        'group transition-colors duration-100',
        hovered && 'bg-surface-1',
        isDone && 'opacity-60',
      )}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Checkbox */}
      <td className="pl-3 py-2.5 w-6">
        <button
          onClick={() => onToggleDone(task)}
          className="text-text-muted hover:text-accent transition-colors"
        >
          {isDone
            ? <CheckCircle2 className="w-4 h-4 text-green-500" />
            : <Circle className="w-4 h-4" />}
        </button>
      </td>

      {/* Title */}
      <td className="px-3 py-2.5">
        <button
          className="text-sm font-medium text-text-primary hover:text-accent transition-colors text-left line-clamp-1"
          onClick={() => onOpen(task)}
        >
          {task.title}
        </button>
        {task.tags.length > 0 && (
          <div className="flex gap-1 mt-0.5">
            {task.tags.slice(0, 2).map((tag) => (
              <span key={tag} className="text-[10px] text-text-muted">#{tag}</span>
            ))}
          </div>
        )}
      </td>

      {/* Status */}
      <td className="px-3 py-2.5">
        <span className={cn('inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-md', STATUS_COLORS[task.status])}>
          <span className={cn('w-1.5 h-1.5 rounded-full', STATUS_DOT[task.status])} />
          {STATUS_LABELS[task.status]}
        </span>
      </td>

      {/* Priority */}
      <td className="px-3 py-2.5">
        <span className={cn('text-xs font-medium px-1.5 py-0.5 rounded-md', PRIORITY_BG[task.priority])}>
          {PRIORITY_LABELS[task.priority]}
        </span>
      </td>

      {/* Assignee */}
      <td className="px-3 py-2.5 hidden md:table-cell">
        {assignee ? (
          <div className="flex items-center gap-1.5">
            <Avatar name={assignee.name} color={assignee.color} size="xs" />
            <span className="text-xs text-text-secondary truncate max-w-[80px]">{assignee.name.split(' ')[0]}</span>
          </div>
        ) : (
          <span className="text-xs text-text-muted">—</span>
        )}
      </td>

      {/* Due date */}
      <td className="px-3 py-2.5 hidden lg:table-cell">
        {task.dueDate ? (
          <span className={cn(
            'flex items-center gap-1 text-xs font-medium w-fit',
            overdue ? 'text-red-500' : dueToday ? 'text-yellow-500' : 'text-text-secondary',
          )}>
            {overdue && <AlertCircle className="w-3 h-3" />}
            {formatDate(task.dueDate)}
          </span>
        ) : (
          <span className="text-xs text-text-muted">—</span>
        )}
      </td>

      {/* Subtask progress */}
      <td className="px-3 py-2.5 hidden lg:table-cell">
        {task.subtasks.length > 0 ? (
          <div className="w-24">
            <ProgressBar
              value={subtasksDone}
              max={task.subtasks.length}
              colorClass={subtasksDone === task.subtasks.length ? 'bg-green-500' : 'bg-accent'}
            />
            <p className="text-[10px] text-text-muted mt-0.5">{subtasksDone}/{task.subtasks.length}</p>
          </div>
        ) : (
          <span className="text-xs text-text-muted">—</span>
        )}
      </td>

      {/* Actions */}
      <td className="px-3 py-2.5 text-right">
        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button variant="ghost" size="xs" className="w-6 h-6 p-0 text-text-muted" onClick={() => onOpen(task)}>
            <Edit3 className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="xs" className="w-6 h-6 p-0 text-red-400 hover:text-red-500" onClick={() => onDelete(task.id)}>
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </td>
    </tr>
  );
}
