// ============================================================
// components/tasks/TaskCard.tsx — Individual task card
// ============================================================

'use client';

import React from 'react';
import {
  Calendar, MessageSquare, Paperclip, CheckSquare,
  AlertCircle, Clock, GripVertical, MoreHorizontal, Trash2, Edit3,
} from 'lucide-react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { useStore } from '@/lib/store';
import { Avatar, Badge, Button, ProgressBar } from '@/components/ui';
import {
  cn, formatDateShort, isOverdue, isDueToday,
  PRIORITY_BG, PRIORITY_LABELS, STATUS_LABELS, STATUS_COLORS,
} from '@/lib/utils';
import type { Task } from '@/types';

interface TaskCardProps {
  task: Task;
  onOpen: (task: Task) => void;
  isDragging?: boolean;
}

export function TaskCard({ task, onOpen, isDragging }: TaskCardProps) {
  const { users, deleteTask } = useStore();
  const assignee = task.assigneeId ? users.find((u) => u.id === task.assigneeId) : null;

  // DnD kit sortable hook
  const { attributes, listeners, setNodeRef, transform, transition, isDragging: isSortableDragging } = useSortable({
    id: task.id,
    data: { type: 'task', task },
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const subtasksDone = task.subtasks.filter((s) => s.completed).length;
  const subtasksTotal = task.subtasks.length;
  const overdue = isOverdue(task);
  const dueToday = isDueToday(task);

  const [showMenu, setShowMenu] = React.useState(false);

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        'group relative rounded-xl bg-surface-0 border border-border shadow-card',
        'hover:shadow-card-hover hover:border-border-strong transition-all duration-150',
        (isSortableDragging || isDragging) && 'opacity-50 shadow-modal scale-[1.02] rotate-1 z-50',
        task.status === 'done' && 'opacity-60',
      )}
    >
      {/* Drag handle */}
      <div
        {...attributes}
        {...listeners}
        className="absolute left-2 top-1/2 -translate-y-1/2 text-text-muted opacity-0 group-hover:opacity-100 cursor-grab active:cursor-grabbing transition-opacity touch-none"
      >
        <GripVertical className="w-3 h-3" />
      </div>

      <div className="p-3 pl-5">
        {/* Header row: priority + menu */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <span className={cn('inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-xs font-medium', PRIORITY_BG[task.priority])}>
            {task.priority === 'critical' && <AlertCircle className="w-2.5 h-2.5" />}
            {PRIORITY_LABELS[task.priority]}
          </span>

          <div className="relative flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="xs"
              className="w-6 h-6 p-0"
              onClick={(e) => { e.stopPropagation(); setShowMenu((v) => !v); }}
            >
              <MoreHorizontal className="w-3.5 h-3.5" />
            </Button>

            {showMenu && (
              <div
                className="absolute right-0 top-7 z-40 w-36 rounded-xl bg-surface-0 border border-border shadow-modal py-1"
                onMouseLeave={() => setShowMenu(false)}
              >
                <button
                  className="w-full px-3 py-1.5 text-sm text-left text-text-secondary hover:bg-surface-2 flex items-center gap-2"
                  onClick={(e) => { e.stopPropagation(); onOpen(task); setShowMenu(false); }}
                >
                  <Edit3 className="w-3.5 h-3.5" /> Edit
                </button>
                <button
                  className="w-full px-3 py-1.5 text-sm text-left text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center gap-2"
                  onClick={(e) => { e.stopPropagation(); deleteTask(task.id); setShowMenu(false); }}
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Title */}
        <button
          className="text-sm font-medium text-text-primary text-left leading-snug hover:text-accent transition-colors w-full mb-2"
          onClick={() => onOpen(task)}
        >
          {task.title}
        </button>

        {/* Tags */}
        {task.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-2">
            {task.tags.slice(0, 3).map((tag) => (
              <span key={tag} className="px-1.5 py-0.5 rounded-md text-[10px] font-medium bg-surface-2 text-text-muted">
                #{tag}
              </span>
            ))}
            {task.tags.length > 3 && (
              <span className="text-[10px] text-text-muted">+{task.tags.length - 3}</span>
            )}
          </div>
        )}

        {/* Subtasks progress */}
        {subtasksTotal > 0 && (
          <div className="mb-2">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-text-muted">
                {subtasksDone}/{subtasksTotal} subtasks
              </span>
              <span className="text-[10px] text-text-muted font-medium">
                {Math.round((subtasksDone / subtasksTotal) * 100)}%
              </span>
            </div>
            <ProgressBar
              value={subtasksDone}
              max={subtasksTotal}
              colorClass={subtasksDone === subtasksTotal ? 'bg-green-500' : 'bg-accent'}
            />
          </div>
        )}

        {/* Footer: date, assignee, metadata */}
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-border/60">
          <div className="flex items-center gap-2">
            {/* Due date */}
            {task.dueDate && (
              <span className={cn(
                'flex items-center gap-1 text-[11px] font-medium',
                overdue ? 'text-red-500' : dueToday ? 'text-yellow-500' : 'text-text-muted',
              )}>
                {overdue ? <AlertCircle className="w-3 h-3" /> : <Calendar className="w-3 h-3" />}
                {formatDateShort(task.dueDate)}
              </span>
            )}

            {/* Metadata icons */}
            {task.comments.length > 0 && (
              <span className="flex items-center gap-0.5 text-[11px] text-text-muted">
                <MessageSquare className="w-3 h-3" />
                {task.comments.length}
              </span>
            )}
            {task.attachments.length > 0 && (
              <span className="flex items-center gap-0.5 text-[11px] text-text-muted">
                <Paperclip className="w-3 h-3" />
                {task.attachments.length}
              </span>
            )}
          </div>

          {/* Assignee */}
          {assignee && (
            <Avatar name={assignee.name} color={assignee.color} size="xs" />
          )}
        </div>
      </div>
    </div>
  );
}
