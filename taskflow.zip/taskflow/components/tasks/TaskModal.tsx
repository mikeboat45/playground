// ============================================================
// components/tasks/TaskModal.tsx — Create / edit task modal
// ============================================================

'use client';

import React, { useEffect, useState } from 'react';
import {
  X, Plus, Trash2, Check, Calendar, Tag, User,
  AlignLeft, Flag, FolderOpen, ChevronDown,
} from 'lucide-react';
import { useStore } from '@/lib/store';
import {
  Button, Input, Textarea, Select, Badge, Avatar, ProgressBar, Divider,
} from '@/components/ui';
import {
  cn, PRIORITY_LABELS, STATUS_LABELS, STATUS_COLORS, STATUS_DOT,
  PRIORITY_BG, formatDate,
} from '@/lib/utils';
import type { Task, TaskStatus, Priority, Subtask } from '@/types';
import { nanoid } from 'nanoid';

interface TaskModalProps {
  task: Task | null;         // null = create mode
  initialStatus?: TaskStatus;
  onClose: () => void;
}

type FormData = {
  title: string;
  description: string;
  status: TaskStatus;
  priority: Priority;
  projectId: string;
  assigneeId: string;
  dueDate: string;
  tags: string;
  estimatedHours: string;
  subtasks: Subtask[];
};

export function TaskModal({ task, initialStatus = 'todo', onClose }: TaskModalProps) {
  const { projects, users, addTask, updateTask } = useStore();
  const isEditing = !!task;

  const [form, setForm] = useState<FormData>({
    title: task?.title ?? '',
    description: task?.description ?? '',
    status: task?.status ?? initialStatus,
    priority: task?.priority ?? 'medium',
    projectId: task?.projectId ?? (projects[0]?.id ?? ''),
    assigneeId: task?.assigneeId ?? '',
    dueDate: task?.dueDate ?? '',
    tags: task?.tags.join(', ') ?? '',
    estimatedHours: task?.estimatedHours?.toString() ?? '',
    subtasks: task?.subtasks ?? [],
  });

  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const [newSubtask, setNewSubtask] = useState('');

  // Close on Escape
  useEffect(() => {
    function handler(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  function set<K extends keyof FormData>(key: K, value: FormData[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: undefined }));
  }

  function validate(): boolean {
    const errs: typeof errors = {};
    if (!form.title.trim()) errs.title = 'Title is required';
    if (!form.projectId) errs.projectId = 'Select a project';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function handleSubmit() {
    if (!validate()) return;

    const tags = form.tags
      .split(',')
      .map((t) => t.trim().toLowerCase().replace(/\s+/g, '-'))
      .filter(Boolean);

    const payload = {
      title: form.title.trim(),
      description: form.description.trim(),
      status: form.status,
      priority: form.priority,
      projectId: form.projectId,
      assigneeId: form.assigneeId || null,
      dueDate: form.dueDate || null,
      tags,
      estimatedHours: form.estimatedHours ? parseFloat(form.estimatedHours) : null,
      subtasks: form.subtasks,
      attachments: task?.attachments ?? [],
      comments: task?.comments ?? [],
    };

    if (isEditing) {
      updateTask(task.id, payload);
    } else {
      addTask(payload);
    }
    onClose();
  }

  function addSubtask() {
    if (!newSubtask.trim()) return;
    set('subtasks', [...form.subtasks, { id: nanoid(8), title: newSubtask.trim(), completed: false }]);
    setNewSubtask('');
  }

  function toggleSubtask(id: string) {
    set('subtasks', form.subtasks.map((s) => s.id === id ? { ...s, completed: !s.completed } : s));
  }

  function removeSubtask(id: string) {
    set('subtasks', form.subtasks.filter((s) => s.id !== id));
  }

  const completedSubtasks = form.subtasks.filter((s) => s.completed).length;

  return (
    // Backdrop
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm p-0 sm:p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="relative w-full sm:max-w-xl bg-surface-0 rounded-t-2xl sm:rounded-2xl shadow-modal border border-border max-h-[90vh] flex flex-col animate-slide-up">

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
          <h2 className="text-base font-semibold text-text-primary font-display">
            {isEditing ? 'Edit Task' : 'New Task'}
          </h2>
          <Button variant="ghost" size="sm" className="w-7 h-7 p-0" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Body — scrollable */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">

          {/* Title */}
          <div>
            <Input
              placeholder="Task title…"
              value={form.title}
              onChange={(e) => set('title', e.target.value)}
              error={errors.title}
              className="h-9 text-base font-medium"
              autoFocus
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-medium text-text-secondary mb-1">Description</label>
            <Textarea
              placeholder="Add more context, acceptance criteria, or notes…"
              value={form.description}
              onChange={(e) => set('description', e.target.value)}
              rows={3}
            />
          </div>

          {/* Row: Status + Priority */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-text-secondary mb-1">Status</label>
              <Select value={form.status} onChange={(e) => set('status', e.target.value as TaskStatus)}>
                {(['todo', 'in-progress', 'blocked', 'done'] as TaskStatus[]).map((s) => (
                  <option key={s} value={s}>{STATUS_LABELS[s]}</option>
                ))}
              </Select>
            </div>
            <div>
              <label className="block text-xs font-medium text-text-secondary mb-1">Priority</label>
              <Select value={form.priority} onChange={(e) => set('priority', e.target.value as Priority)}>
                {(['low', 'medium', 'high', 'critical'] as Priority[]).map((p) => (
                  <option key={p} value={p}>{PRIORITY_LABELS[p]}</option>
                ))}
              </Select>
            </div>
          </div>

          {/* Row: Project + Assignee */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-text-secondary mb-1">Project</label>
              <Select
                value={form.projectId}
                onChange={(e) => set('projectId', e.target.value)}
                className={errors.projectId ? 'border-red-500' : ''}
              >
                <option value="">Select project…</option>
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>{p.emoji} {p.name}</option>
                ))}
              </Select>
              {errors.projectId && <p className="mt-1 text-xs text-red-500">{errors.projectId}</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-text-secondary mb-1">Assignee</label>
              <Select value={form.assigneeId} onChange={(e) => set('assigneeId', e.target.value)}>
                <option value="">Unassigned</option>
                {users.map((u) => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
              </Select>
            </div>
          </div>

          {/* Row: Due date + Estimated hours */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-text-secondary mb-1">Due Date</label>
              <Input
                type="date"
                value={form.dueDate}
                onChange={(e) => set('dueDate', e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-text-secondary mb-1">Estimated Hours</label>
              <Input
                type="number"
                min="0"
                step="0.5"
                placeholder="e.g. 4"
                value={form.estimatedHours}
                onChange={(e) => set('estimatedHours', e.target.value)}
              />
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="block text-xs font-medium text-text-secondary mb-1">
              Tags <span className="text-text-muted font-normal">(comma-separated)</span>
            </label>
            <Input
              placeholder="design, frontend, bug…"
              value={form.tags}
              onChange={(e) => set('tags', e.target.value)}
            />
          </div>

          {/* Subtasks */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-text-secondary">
                Subtasks {form.subtasks.length > 0 && `(${completedSubtasks}/${form.subtasks.length})`}
              </label>
              {form.subtasks.length > 0 && (
                <ProgressBar
                  value={completedSubtasks}
                  max={form.subtasks.length}
                  className="w-20"
                  colorClass="bg-green-500"
                />
              )}
            </div>

            <div className="space-y-1 mb-2">
              {form.subtasks.map((st) => (
                <div key={st.id} className="flex items-center gap-2 group/st">
                  <button
                    onClick={() => toggleSubtask(st.id)}
                    className={cn(
                      'shrink-0 w-4 h-4 rounded border flex items-center justify-center transition-colors',
                      st.completed
                        ? 'bg-green-500 border-green-500 text-white'
                        : 'border-border hover:border-accent',
                    )}
                  >
                    {st.completed && <Check className="w-2.5 h-2.5" />}
                  </button>
                  <span className={cn('flex-1 text-sm', st.completed && 'line-through text-text-muted')}>
                    {st.title}
                  </span>
                  <button
                    onClick={() => removeSubtask(st.id)}
                    className="opacity-0 group-hover/st:opacity-100 text-text-muted hover:text-red-500 transition-all"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <Input
                placeholder="Add a subtask…"
                value={newSubtask}
                onChange={(e) => setNewSubtask(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addSubtask())}
                className="flex-1"
              />
              <Button variant="outline" size="sm" onClick={addSubtask} disabled={!newSubtask.trim()}>
                <Plus className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-border shrink-0">
          <Button variant="ghost" size="sm" onClick={onClose}>Cancel</Button>
          <Button variant="primary" size="sm" onClick={handleSubmit}>
            {isEditing ? 'Save Changes' : 'Create Task'}
          </Button>
        </div>
      </div>
    </div>
  );
}
