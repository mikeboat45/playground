// ============================================================
// components/tasks/KanbanBoard.tsx — Drag-and-drop kanban view
// ============================================================

'use client';

import React, { useState, useMemo } from 'react';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  closestCorners,
  type DragStartEvent,
  type DragOverEvent,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
  arrayMove,
} from '@dnd-kit/sortable';
import { useDroppable } from '@dnd-kit/core';
import { Plus, MoreHorizontal } from 'lucide-react';
import { useStore, useFilteredTasks } from '@/lib/store';
import { TaskCard } from './TaskCard';
import { Button, Badge, EmptyState } from '@/components/ui';
import { cn, STATUS_LABELS, STATUS_DOT } from '@/lib/utils';
import type { Task, TaskStatus } from '@/types';

const COLUMNS: { id: TaskStatus; label: string }[] = [
  { id: 'todo', label: 'To Do' },
  { id: 'in-progress', label: 'In Progress' },
  { id: 'blocked', label: 'Blocked' },
  { id: 'done', label: 'Done' },
];

interface KanbanBoardProps {
  onOpenTask: (task: Task) => void;
  onNewTask: (status?: TaskStatus) => void;
}

export function KanbanBoard({ onOpenTask, onNewTask }: KanbanBoardProps) {
  const { moveTask, reorderTasks } = useStore();
  const allFilteredTasks = useFilteredTasks();

  const [activeTask, setActiveTask] = useState<Task | null>(null);

  // Group tasks by status, preserving order
  const tasksByStatus = useMemo(() => {
    const map: Record<TaskStatus, Task[]> = {
      'todo': [], 'in-progress': [], 'blocked': [], 'done': [],
    };
    allFilteredTasks.forEach((t) => {
      map[t.status].push(t);
    });
    // Sort each column by order field
    Object.keys(map).forEach((status) => {
      map[status as TaskStatus].sort((a, b) => a.order - b.order);
    });
    return map;
  }, [allFilteredTasks]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
  );

  function onDragStart(event: DragStartEvent) {
    const task = event.active.data.current?.task as Task | undefined;
    if (task) setActiveTask(task);
  }

  function onDragEnd(event: DragEndEvent) {
    setActiveTask(null);
    const { active, over } = event;
    if (!over) return;

    const activeId = active.id as string;
    const overId = over.id as string;

    const activeTask = allFilteredTasks.find((t) => t.id === activeId);
    if (!activeTask) return;

    // Dropped on a column (droppable area)
    const targetColumnId = COLUMNS.find((c) => c.id === overId)?.id;
    if (targetColumnId) {
      const columnTasks = tasksByStatus[targetColumnId];
      moveTask(activeId, targetColumnId, columnTasks.length);
      return;
    }

    // Dropped on another task — reorder within same column or move to new column
    const overTask = allFilteredTasks.find((t) => t.id === overId);
    if (!overTask) return;

    if (activeTask.status === overTask.status) {
      // Reorder within same column
      const column = tasksByStatus[activeTask.status];
      const oldIdx = column.findIndex((t) => t.id === activeId);
      const newIdx = column.findIndex((t) => t.id === overId);
      const reordered = arrayMove(column, oldIdx, newIdx);
      reorderTasks(activeTask.status, reordered.map((t) => t.id));
    } else {
      // Move to new column at position of over task
      const overColumn = tasksByStatus[overTask.status];
      const newOrder = overColumn.findIndex((t) => t.id === overId);
      moveTask(activeId, overTask.status, newOrder);
    }
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCorners}
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
    >
      <div className="flex gap-3 h-full overflow-x-auto pb-4 px-4 pt-3">
        {COLUMNS.map((column) => (
          <KanbanColumn
            key={column.id}
            id={column.id}
            label={column.label}
            tasks={tasksByStatus[column.id]}
            onOpenTask={onOpenTask}
            onNewTask={() => onNewTask(column.id)}
          />
        ))}
      </div>

      {/* Drag overlay — renders the card being dragged */}
      <DragOverlay dropAnimation={{ duration: 200, easing: 'cubic-bezier(0.18, 0.67, 0.6, 1.22)' }}>
        {activeTask && (
          <TaskCard task={activeTask} onOpen={() => {}} isDragging />
        )}
      </DragOverlay>
    </DndContext>
  );
}

// ─── Kanban Column ────────────────────────────────────────────

interface KanbanColumnProps {
  id: TaskStatus;
  label: string;
  tasks: Task[];
  onOpenTask: (task: Task) => void;
  onNewTask: () => void;
}

function KanbanColumn({ id, label, tasks, onOpenTask, onNewTask }: KanbanColumnProps) {
  const { isOver, setNodeRef } = useDroppable({ id });

  const columnColors: Record<TaskStatus, string> = {
    'todo': 'bg-slate-500',
    'in-progress': 'bg-blue-500',
    'blocked': 'bg-red-500',
    'done': 'bg-green-500',
  };

  return (
    <div className="flex flex-col w-64 shrink-0">
      {/* Column header */}
      <div className="flex items-center gap-2 mb-2.5 px-1">
        <span className={cn('w-2 h-2 rounded-full', columnColors[id])} />
        <span className="text-sm font-semibold text-text-primary">{label}</span>
        <span className="ml-auto text-xs font-medium text-text-muted bg-surface-2 rounded-full px-1.5 py-0.5">
          {tasks.length}
        </span>
        <Button
          variant="ghost"
          size="xs"
          className="w-5 h-5 p-0 text-text-muted"
          onClick={onNewTask}
        >
          <Plus className="w-3.5 h-3.5" />
        </Button>
      </div>

      {/* Drop zone */}
      <div
        ref={setNodeRef}
        className={cn(
          'flex-1 min-h-[120px] rounded-xl p-2 space-y-2 transition-colors duration-150',
          isOver ? 'bg-accent/5 ring-2 ring-accent/30' : 'bg-surface-1/50',
        )}
      >
        <SortableContext items={tasks.map((t) => t.id)} strategy={verticalListSortingStrategy}>
          {tasks.map((task) => (
            <TaskCard key={task.id} task={task} onOpen={onOpenTask} />
          ))}
        </SortableContext>

        {tasks.length === 0 && (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <p className="text-xs text-text-muted">Drop tasks here</p>
          </div>
        )}

        {/* Add task button at bottom */}
        <button
          onClick={onNewTask}
          className="w-full py-1.5 text-xs text-text-muted hover:text-text-secondary hover:bg-surface-2 rounded-lg transition-colors flex items-center justify-center gap-1"
        >
          <Plus className="w-3 h-3" /> Add task
        </button>
      </div>
    </div>
  );
}
