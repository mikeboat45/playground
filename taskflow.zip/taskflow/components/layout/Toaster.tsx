// ============================================================
// components/layout/Toaster.tsx — Toast notifications
// ============================================================

'use client';

import React from 'react';
import { CheckCircle2, XCircle, AlertTriangle, Info, X } from 'lucide-react';
import { useStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import type { NotificationType } from '@/types';

const ICONS: Record<NotificationType, React.ReactNode> = {
  success: <CheckCircle2 className="w-4 h-4 text-green-500" />,
  error: <XCircle className="w-4 h-4 text-red-500" />,
  warning: <AlertTriangle className="w-4 h-4 text-yellow-500" />,
  info: <Info className="w-4 h-4 text-blue-500" />,
};

const COLORS: Record<NotificationType, string> = {
  success: 'border-l-green-500',
  error: 'border-l-red-500',
  warning: 'border-l-yellow-500',
  info: 'border-l-blue-500',
};

export function Toaster() {
  const { notifications, removeNotification } = useStore();

  if (notifications.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2 max-w-xs w-full pointer-events-none">
      {notifications.map((n) => (
        <div
          key={n.id}
          className={cn(
            'pointer-events-auto flex items-start gap-3 p-3 rounded-xl bg-surface-0 border border-border border-l-4 shadow-modal',
            'animate-slide-in-right',
            COLORS[n.type],
          )}
        >
          <span className="shrink-0 mt-0.5">{ICONS[n.type]}</span>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-text-primary">{n.title}</p>
            {n.message && <p className="text-xs text-text-muted mt-0.5 truncate">{n.message}</p>}
          </div>
          <button
            onClick={() => removeNotification(n.id)}
            className="shrink-0 text-text-muted hover:text-text-primary transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
}
