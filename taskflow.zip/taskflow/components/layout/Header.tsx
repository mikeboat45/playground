// ============================================================
// components/layout/Header.tsx — Top bar
// ============================================================

'use client';

import React from 'react';
import { Search, LayoutGrid, List, Sun, Moon, Monitor, SlidersHorizontal, Bell, X } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useTheme, useLocalSearch } from '@/hooks';
import { Button, Input, Tooltip, Badge } from '@/components/ui';
import { cn } from '@/lib/utils';
import type { ViewMode } from '@/types';

interface HeaderProps {
  onFilterClick: () => void;
  activeFilterCount: number;
}

export function Header({ onFilterClick, activeFilterCount }: HeaderProps) {
  const { viewMode, setViewMode } = useStore();
  const { resolvedTheme, setTheme } = useTheme();
  const { localSearch, setLocalSearch } = useLocalSearch();
  const { notifications, removeNotification } = useStore();

  const viewModes: { id: ViewMode; icon: React.ReactNode; label: string }[] = [
    { id: 'board', icon: <LayoutGrid className="w-3.5 h-3.5" />, label: 'Board' },
    { id: 'list', icon: <List className="w-3.5 h-3.5" />, label: 'List' },
  ];

  return (
    <header className="h-12 shrink-0 px-4 flex items-center gap-3 bg-surface-0 border-b border-border">
      {/* Search */}
      <div className="flex-1 max-w-sm">
        <Input
          placeholder="Search tasks… (⌘K)"
          value={localSearch}
          onChange={(e) => setLocalSearch(e.target.value)}
          icon={<Search className="w-3.5 h-3.5" />}
          iconRight={
            localSearch ? (
              <button onClick={() => setLocalSearch('')} className="hover:text-text-primary transition-colors">
                <X className="w-3.5 h-3.5" />
              </button>
            ) : null
          }
        />
      </div>

      <div className="flex items-center gap-1.5 ml-auto">
        {/* Filter Button */}
        <Button
          variant="outline"
          size="sm"
          icon={<SlidersHorizontal className="w-3.5 h-3.5" />}
          onClick={onFilterClick}
          className="relative"
        >
          Filters
          {activeFilterCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-accent rounded-full text-[10px] text-white flex items-center justify-center font-bold">
              {activeFilterCount}
            </span>
          )}
        </Button>

        {/* View Mode Toggle */}
        <div className="flex items-center rounded-lg border border-border bg-surface-1 p-0.5">
          {viewModes.map(({ id, icon, label }) => (
            <Tooltip key={id} label={label}>
              <button
                onClick={() => setViewMode(id)}
                className={cn(
                  'flex items-center justify-center w-6 h-6 rounded-md transition-all duration-150',
                  viewMode === id
                    ? 'bg-surface-0 shadow-sm text-text-primary'
                    : 'text-text-muted hover:text-text-secondary',
                )}
              >
                {icon}
              </button>
            </Tooltip>
          ))}
        </div>

        {/* Theme Toggle */}
        <Tooltip label={resolvedTheme === 'dark' ? 'Light mode' : 'Dark mode'}>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')}
            className="w-8 h-8 p-0"
          >
            {resolvedTheme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          </Button>
        </Tooltip>
      </div>
    </header>
  );
}
