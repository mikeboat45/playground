// ============================================================
// components/layout/Sidebar.tsx — Navigation sidebar
// ============================================================

'use client';

import React from 'react';
import {
  LayoutGrid, List, Calendar, BarChart3, Settings,
  Plus, ChevronRight, FolderOpen, Inbox, Star, CheckCircle2,
  AlertCircle, Clock, Hash,
} from 'lucide-react';
import { useStore, useCurrentUser, useTaskStats } from '@/lib/store';
import { Avatar, Button, Badge, ProgressBar } from '@/components/ui';
import { cn } from '@/lib/utils';
import type { Project } from '@/types';

interface SidebarProps {
  onNewProject: () => void;
  onNewTask: () => void;
}

export function Sidebar({ onNewProject, onNewTask }: SidebarProps) {
  const { projects, activeProjectId, setActiveProject, tasks } = useStore();
  const currentUser = useCurrentUser();
  const stats = useTaskStats();

  const navItems = [
    { id: 'all', label: 'All Tasks', icon: <Inbox className="w-4 h-4" />, count: tasks.filter(t => t.status !== 'done').length },
    { id: 'today', label: 'Due Today', icon: <Star className="w-4 h-4" />, count: tasks.filter(t => { const d = t.dueDate; if (!d || t.status === 'done') return false; const today = new Date(); const due = new Date(d); return due.toDateString() === today.toDateString(); }).length },
    { id: 'overdue', label: 'Overdue', icon: <AlertCircle className="w-4 h-4" />, count: tasks.filter(t => { if (!t.dueDate || t.status === 'done') return false; return new Date(t.dueDate) < new Date(); }).length },
    { id: 'done', label: 'Completed', icon: <CheckCircle2 className="w-4 h-4" />, count: tasks.filter(t => t.status === 'done').length },
  ];

  return (
    <aside className="w-56 shrink-0 h-full flex flex-col bg-surface-0 border-r border-border overflow-y-auto">
      {/* Logo */}
      <div className="px-4 py-4 flex items-center gap-2.5">
        <div className="w-7 h-7 rounded-lg bg-accent flex items-center justify-center shrink-0">
          <CheckCircle2 className="w-4 h-4 text-white" />
        </div>
        <span className="font-display font-bold text-text-primary tracking-tight text-base">TaskFlow</span>
      </div>

      {/* New Task CTA */}
      <div className="px-3 mb-3">
        <Button variant="primary" size="sm" className="w-full justify-start gap-2" icon={<Plus className="w-3.5 h-3.5" />} onClick={onNewTask}>
          New Task
        </Button>
      </div>

      {/* Quick Nav */}
      <nav className="px-2 mb-4">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              if (item.id === 'all') { setActiveProject(null); useStore.getState().setFilters({ statuses: [], showCompleted: true }); }
              else if (item.id === 'done') { setActiveProject(null); useStore.getState().setFilters({ statuses: ['done'], showCompleted: true }); }
              else if (item.id === 'today') { setActiveProject(null); useStore.getState().setFilters({ statuses: ['todo', 'in-progress', 'blocked'], showCompleted: false }); }
            }}
            className={cn(
              'w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-sm transition-colors',
              activeProjectId === null && item.id === 'all'
                ? 'bg-accent/10 text-accent font-medium'
                : 'text-text-secondary hover:bg-surface-2 hover:text-text-primary',
            )}
          >
            <span className="flex items-center gap-2">{item.icon}{item.label}</span>
            {item.count > 0 && (
              <span className={cn(
                'text-xs rounded-full px-1.5 py-0.5 font-medium',
                item.id === 'overdue' ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' : 'bg-surface-2 text-text-muted'
              )}>
                {item.count}
              </span>
            )}
          </button>
        ))}
      </nav>

      {/* Projects Section */}
      <div className="px-3 mb-2 flex items-center justify-between">
        <span className="text-xs font-semibold text-text-muted uppercase tracking-wider">Projects</span>
        <Button variant="ghost" size="xs" icon={<Plus className="w-3.5 h-3.5" />} onClick={onNewProject} className="text-text-muted hover:text-text-primary" />
      </div>

      <div className="px-2 space-y-0.5 flex-1">
        {projects.map((project) => (
          <ProjectNavItem
            key={project.id}
            project={project}
            isActive={activeProjectId === project.id}
            taskCount={tasks.filter((t) => t.projectId === project.id && t.status !== 'done').length}
            onClick={() => setActiveProject(activeProjectId === project.id ? null : project.id)}
          />
        ))}
      </div>

      {/* User Footer */}
      <div className="px-3 py-3 border-t border-border mt-3">
        <div className="flex items-center gap-2.5">
          <Avatar name={currentUser.name} color={currentUser.color} size="sm" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-text-primary truncate">{currentUser.name}</p>
            <p className="text-xs text-text-muted capitalize">{currentUser.role}</p>
          </div>
          <Button variant="ghost" size="xs" className="text-text-muted shrink-0">
            <Settings className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </aside>
  );
}

function ProjectNavItem({
  project,
  isActive,
  taskCount,
  onClick,
}: {
  project: Project;
  isActive: boolean;
  taskCount: number;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-sm transition-all duration-150',
        isActive
          ? 'bg-surface-2 text-text-primary font-medium'
          : 'text-text-secondary hover:bg-surface-2 hover:text-text-primary',
      )}
    >
      <span className="text-base leading-none shrink-0">{project.emoji}</span>
      <span className="flex-1 truncate text-left">{project.name}</span>
      {taskCount > 0 && (
        <span className="text-xs text-text-muted shrink-0">{taskCount}</span>
      )}
    </button>
  );
}
