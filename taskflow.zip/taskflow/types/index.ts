// ============================================================
// types/index.ts — Central type definitions for TaskFlow
// ============================================================

export type Priority = 'low' | 'medium' | 'high' | 'critical';
export type TaskStatus = 'todo' | 'in-progress' | 'done' | 'blocked';
export type ViewMode = 'board' | 'list' | 'timeline';
export type Theme = 'light' | 'dark' | 'system';

// ─── Task ────────────────────────────────────────────────────
export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: Priority;
  projectId: string;
  assigneeId: string | null;
  tags: string[];
  dueDate: string | null;       // ISO date string
  createdAt: string;            // ISO datetime string
  updatedAt: string;
  completedAt: string | null;
  estimatedHours: number | null;
  loggedHours: number;
  subtasks: Subtask[];
  attachments: Attachment[];
  comments: Comment[];
  order: number;                // for drag-and-drop ordering within a column
}

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Attachment {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number;
  uploadedAt: string;
}

export interface Comment {
  id: string;
  authorId: string;
  content: string;
  createdAt: string;
}

// ─── Project ─────────────────────────────────────────────────
export interface Project {
  id: string;
  name: string;
  description: string;
  color: string;               // hex color for visual identification
  emoji: string;
  ownerId: string;
  memberIds: string[];
  createdAt: string;
  archivedAt: string | null;
}

// ─── User / Team Member ──────────────────────────────────────
export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;              // initials or URL
  role: 'owner' | 'admin' | 'member' | 'viewer';
  color: string;               // avatar background color
}

// ─── Filters & Sorting ───────────────────────────────────────
export interface TaskFilters {
  search: string;
  statuses: TaskStatus[];
  priorities: Priority[];
  projectIds: string[];
  assigneeIds: string[];
  tags: string[];
  dueDateRange: { from: string | null; to: string | null };
  showCompleted: boolean;
}

export type SortField = 'createdAt' | 'dueDate' | 'priority' | 'title' | 'status';
export type SortDirection = 'asc' | 'desc';

export interface SortConfig {
  field: SortField;
  direction: SortDirection;
}

// ─── Analytics ───────────────────────────────────────────────
export interface TaskStats {
  total: number;
  byStatus: Record<TaskStatus, number>;
  byPriority: Record<Priority, number>;
  completionRate: number;
  overdueCount: number;
  dueTodayCount: number;
  averageCompletionHours: number | null;
}

export interface ActivityEntry {
  id: string;
  type: 'created' | 'status_changed' | 'assigned' | 'commented' | 'completed';
  taskId: string;
  taskTitle: string;
  userId: string;
  metadata: Record<string, unknown>;
  timestamp: string;
}

// ─── Drag & Drop ─────────────────────────────────────────────
export interface DragItem {
  id: string;
  type: 'task';
  sourceStatus: TaskStatus;
  sourceIndex: number;
}

// ─── Notification ────────────────────────────────────────────
export type NotificationType = 'success' | 'error' | 'warning' | 'info';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message?: string;
  duration?: number;
}

// ─── Store Shape ─────────────────────────────────────────────
export interface AppState {
  tasks: Task[];
  projects: Project[];
  users: User[];
  currentUserId: string;
  filters: TaskFilters;
  sort: SortConfig;
  viewMode: ViewMode;
  theme: Theme;
  activeProjectId: string | null;
  notifications: Notification[];
  activityLog: ActivityEntry[];
  isLoading: boolean;

  // Task actions
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'completedAt' | 'loggedHours' | 'order'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  moveTask: (taskId: string, newStatus: TaskStatus, newOrder: number) => void;
  reorderTasks: (status: TaskStatus, orderedIds: string[]) => void;

  // Project actions
  addProject: (project: Omit<Project, 'id' | 'createdAt'>) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;

  // UI actions
  setFilters: (filters: Partial<TaskFilters>) => void;
  resetFilters: () => void;
  setSort: (sort: SortConfig) => void;
  setViewMode: (mode: ViewMode) => void;
  setTheme: (theme: Theme) => void;
  setActiveProject: (id: string | null) => void;

  // Notifications
  addNotification: (n: Omit<Notification, 'id'>) => void;
  removeNotification: (id: string) => void;
}
